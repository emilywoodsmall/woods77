# Transit Delay Forecasting Engine: Phase 1 Architecture

**Status:** Design document. Parts of it are implemented; see [ROADMAP.md](../ROADMAP.md) for what exists today and what is still planned.
**Scope:** Given a GTFS static feed and a historical stream of GTFS-Realtime observations, reconstruct a trustworthy, reproducible, stop-level history of what actually happened.
**Reference agency:** Butler County RTA (BCRTA). It is used as the first test case only. Nothing in the core logic is BCRTA-specific.

## Contents

0. What the BCRTA data taught us
1. Architecture overview
2. Data flow
3. Storage layout and identifiers
4. Time model (service dates, >24:00, DST)
5. Schema: raw layer
6. Schema: normalized static GTFS
7. Schema: normalized GTFS-Realtime
8. Schema: reconstructed layer (stop_events and friends)
9. Static GTFS → realtime join rules
10. Stop-event reconstruction algorithm
11. Evidence hierarchy
12. Edge-case handling
13. Data quality and validation
14. Idempotency and reproducibility
15. Leakage prevention and prediction targets
16. Worked synthetic example
17. Technology stack
18. Project structure
19. Agency configuration (BCRTA example)
20. Implementation plan
21. Decisions needing your approval

---

## 0. What the BCRTA data taught us

These findings come from BCRTA's Fall 2026 static feed plus one UTC day (2026-09-16) of archived realtime data. They are the reason several design choices below exist.

| Finding | Design consequence |
|---|---|
| Realtime `trip_id`s join 100% to `trips.txt`; (trip_id, stop_sequence, stop_id) matches `stop_times.txt` 99.3% | Joining on `trip_id` + `stop_sequence` is the primary key strategy. `stop_id` is a cross-check. |
| 120 of 715 trips visit the same `stop_id` twice (loops) | `stop_id` can never be part of a stop-event key. `stop_sequence` is. GPS projection must be monotone along the shape. |
| Trip Updates: `arrival_time == departure_time` always; no `delay`, no `uncertainty` | Trip Updates are **predictions only**. They cannot separate arrival from departure. |
| Passed stops drop out of Trip Updates, typically ~8 s before the last predicted time, with wide tails | "Stop dropped out" is usable as weak, labeled evidence, never as an observation. |
| Vehicle Positions: `current_status`, `stop_id`, `current_stop_sequence` are **never populated** | No observed stop events exist for BCRTA. Every time is inferred and labeled. |
| GPS fix every ~20 s per bus; median age at fetch 2.7 s; speed quantized to 1 mph | Shape-based interpolation is the primary method. Speed is a helper signal only. |
| ~12% of scheduled stop visits have ≥2 stationary GPS fixes near the stop | Separate arrival/departure times exist only for a minority. The main label is a single **passage time**. |
| 18% of Trip Update rows have blank `trip_id`; trip identity is only in `entity_id` (`detour_1256_trip_WkTR3SB11615`) and runs alongside the normal update | Agency-specific trip-resolution rules live in config. Detour updates are a separate evidence stream, never silently merged. |
| Archive files are partitioned by UTC date; the "Sept 16" file includes 45 trips from the Sept 15 service day | Everything is grouped by **service date** (from `start_date`), never by file date. |
| Flattened archive files cannot distinguish "feed returned zero vehicles" from "collector down" | Our own raw layer logs every fetch attempt, including empty and failed ones. |
| Only 21% of `stop_times` are timepoints; non-timepoint times are scheduler-interpolated and rounded to the minute | `is_timepoint` is carried on every event. Timepoint-only targets are an option. |
| No scheduled times ≥ 24:00:00 in this feed (max 23:20) | Post-midnight handling is tested with synthetic data, since BCRTA won't exercise it. |
| `route_id` blank in all realtime rows | Route comes from static GTFS via `trip_id`. |

---

## 1. Architecture overview

```
                        ┌──────────────────────────────────────────┐
                        │            config/feeds/*.yaml           │
                        │  (feed URLs, timezone, quirks, thresholds)│
                        └───────────────────┬──────────────────────┘
                                            │
   SOURCES                                  ▼
 ┌──────────────┐   ┌───────────────┐   ┌──────────────────────────────────────────────┐
 │ Static GTFS  │   │ Live GTFS-RT  │   │ Archive backfill (gtfsrt.io Parquet, others) │
 │  zip (URL)   │   │ VP / TU / SA  │   │                                              │
 └──────┬───────┘   └──────┬────────┘   └───────────────────────┬──────────────────────┘
        │                  │ collector (polls every N s)        │ archive adapter
        ▼                  ▼                                    ▼
 ╔════════════════════════════════════════════════════════════════════════════════════╗
 ║ LAYER 1  RAW (immutable, append-only, content-addressed)                           ║
 ║   static zips + manifests │ .pb payloads │ fetch_log (every attempt, incl. empty)  ║
 ╚══════════════════════════════════════╤═════════════════════════════════════════════╝
                                        │ decode + validate (deterministic)
                                        ▼
 ╔════════════════════════════════════════════════════════════════════════════════════╗
 ║ LAYER 2  NORMALIZED                                                                ║
 ║   static: agency, routes, trips, stop_times, stops, shapes, calendar(_dates) ...   ║
 ║   derived: static_versions, service_days, scheduled_stop_visits (the "spine")      ║
 ║   realtime: rt_snapshots, rt_trip_updates, rt_stop_time_updates,                   ║
 ║             rt_vehicle_positions, vehicle_fixes (deduplicated)                     ║
 ╚══════════════════════════════════════╤═════════════════════════════════════════════╝
                                        │ reconstruct per (feed_id, service_date)
                                        ▼
 ╔════════════════════════════════════════════════════════════════════════════════════╗
 ║ LAYER 3  RECONSTRUCTED                                                             ║
 ║   trip_instances │ vehicle_trip_assignments │ stop_events │ stop_event_evidence    ║
 ║   prediction_history │ qc_results                                                  ║
 ╚══════════════════════════════════════╤═════════════════════════════════════════════╝
                                        │ as-of joins only (Phase 2)
                                        ▼
 ╔══════════════════════════════╗     ╔═══════════════════╗
 ║ LAYER 4  FEATURES (Phase 2)  ║ ──▶ ║ LAYER 5  MODEL    ║
 ╚══════════════════════════════╝     ╚═══════════════════╝

 Query/catalog: one DuckDB file exposes every layer as tables/views over Parquet.
```

Core principles:

1. **Raw is sacred.** Raw bytes are never modified or deleted. Every downstream row can be traced to a raw payload hash.
2. **Each layer is a pure function of the layer below plus versioned code and config.** Delete Layers 2–3 and regenerate them, and you get identical output.
3. **Nothing is "actual" without a method label.** Every reconstructed time carries how it was obtained and how uncertain it is.
4. **Every observation carries an `available_at` time**, meaning when we first could have known it. This is the foundation of leakage prevention.

---

## 2. Data flow

```
 STATIC PATH (on each new feed version; typically a few times a year)
 ───────────────────────────────────────────────────────────────────
 download zip ─▶ sha256 ─▶ already stored? ──yes──▶ record "seen again" in static_fetch_log; stop
                              │ no
                              ▼
               write raw/gtfs_static/.../gtfs.zip + manifest.json
                              ▼
               run MobilityData gtfs-validator ─▶ store report.json beside zip
                              ▼
               parse CSVs (all as text) ─▶ type/cast ─▶ own integrity checks
                              ▼
               load normalized tables keyed by static_version_id
                              ▼
               expand service_days ─▶ build scheduled_stop_visits (per service date)

 REALTIME PATH (continuous)
 ──────────────────────────
 every 20 s per feed kind:
   HTTP GET ─▶ fetch_log row (status, bytes, latency, error) ─▶ if body: sha256
     ─▶ new payload? write raw .pb (content-addressed) ─▶ rt_snapshots row
 hourly/daily batch:
   decode new payloads ─▶ rt_trip_updates / rt_stop_time_updates / rt_vehicle_positions
     ─▶ resolve trip identity (standard fields, then config rules) ─▶ resolve service_date
     ─▶ dedupe vehicle fixes ─▶ prediction_history (change-only)

 RECONSTRUCTION PATH (per service date, after the day closes + grace period)
 ───────────────────────────────────────────────────────────────────────────
 scheduled_stop_visits(service_date) + added trips
   ─▶ trip_instances ─▶ vehicle_trip_assignments
   ─▶ per trip instance: project fixes onto shape ─▶ generate candidate evidence per stop
   ─▶ select by evidence hierarchy ─▶ monotonicity/consistency pass
   ─▶ write stop_events + stop_event_evidence (atomic partition replace)
   ─▶ qc_results for that service date
```

The grace period (default 6 h after the last scheduled trip of a service date ends) exists so late-arriving archive data and trips running past midnight are included before a service date is reconstructed. Re-running later is always allowed and deterministic.

---

## 3. Storage layout and identifiers

```
data/
  raw/
    gtfs_static/feed_id=bcrta/sha256=<64hex>/gtfs.zip
                                            /manifest.json      # url, fetched_at, http headers, size
                                            /validator_report.json
    gtfs_rt/feed_id=bcrta/kind=vehicle_positions/fetch_date=2026-09-16/<sha256>.pb
    gtfs_rt_archive/feed_id=bcrta/source=gtfsrt_io/kind=.../date=.../data.parquet   # third-party, kept as-is
    fetch_log/feed_id=bcrta/fetch_date=2026-09-16/part-*.parquet
  normalized/
    static/<table>/feed_id=bcrta/static_version_id=<id>/*.parquet
    derived/scheduled_stop_visits/feed_id=bcrta/service_date=2026-09-16/*.parquet
    rt/<table>/feed_id=bcrta/service_date=2026-09-16/*.parquet
  reconstructed/<table>/feed_id=bcrta/service_date=2026-09-16/*.parquet
  catalog.duckdb      # views over the Parquet above + run ledger + small static tables
```

The raw `.pb` files are partitioned by **UTC fetch date**, because that's a physical fact about the fetch. Everything above raw is partitioned by **service date**, because that's the analytical unit.

### Identifier rules

All IDs are deterministic, so re-processing produces the same IDs.

| ID | Definition | Why |
|---|---|---|
| `feed_id` | Short slug from config (`bcrta`) | Namespaces everything. Agencies' own IDs can collide across feeds. |
| `static_version_id` | First 16 hex chars of sha256 of the zip bytes | Same bytes produce the same version, no matter when downloaded. |
| `payload_sha256` | sha256 of raw `.pb` bytes | Content addressing. Identical payloads fetched twice are stored once. |
| `fetch_id` | hash(feed_id, kind, fetch_started_at, url) | One per HTTP attempt, including failures. |
| `observation_id` | hash(payload_sha256, entity_index[, stu_index]) | Stable pointer from a normalized row back to its exact place in a raw payload. |
| `trip_instance_id` | hash(feed_id, service_date, trip_id, start_time or '') | One scheduled or added run of a trip on one service date. |
| `stop_event_id` | hash(trip_instance_id, stop_sequence) | One stop visit. `stop_id` is deliberately excluded (loops). |
| `run_id` | hash(algorithm_version, config_hash, input manifest hash) | Identifies a reconstruction run. The same inputs and code give the same run_id. |

---

## 4. Time model

### 4.1 Definitions

- **Instant:** a point in physical time. Always stored as `TIMESTAMPTZ` in UTC, or as Unix seconds for raw realtime fields.
- **Service date:** the operating day a trip belongs to (`YYYY-MM-DD`), as defined by `calendar.txt`/`calendar_dates.txt`. It is not a calendar date of any instant.
- **GTFS service time:** `HH:MM:SS` in `stop_times.txt`, which may be ≥ 24:00:00. It is stored as **integer seconds** (`25:30:00` → 91800). It is never parsed as a clock time.
- **Agency timezone:** from `agency.txt` (`America/New_York`), overridable per stop via `stop_timezone` (the spec says stop times are still interpreted in the agency timezone. We record `stop_timezone` but don't use it for schedule math).

### 4.2 The conversion rule

The GTFS spec defines service time as measured from **"noon minus 12 hours"** on the service date in the agency timezone. On normal days that's midnight. On DST-change days it isn't.

```
service_day_anchor(service_date, tz) = localize(service_date 12:00:00, tz) − 12 hours
scheduled_instant_utc = service_day_anchor + gtfs_seconds
```

Consequences, all covered by unit tests:

| Case | Example | Result |
|---|---|---|
| After midnight | service_date 2026-09-16, `25:30:00` | 2026-09-17 01:30 EDT (05:30Z). It stays attached to service date 09-16. |
| Spring forward | service_date 2026-03-08, `03:30:00` | anchor = 2026-03-08 12:00 EDT − 12h = **2026-03-07 23:00 EST**; + 3.5 h → 07:30Z = **03:30 EDT**. It stays consistent with the spec. |
| Fall back | service_date 2026-11-01, `01:30:00` | anchor = 2026-11-01 12:00 EST − 12h = 2026-11-01 **01:00 EDT**; + 1.5 h → 01:30 EST (the *second* 01:30), matching the noon-minus-12h rule. |
| Realtime Unix time | `1789516810` | Already an instant. Never needs a timezone to be stored. The timezone is used only for display and for deriving local features. |

Library: Python's `zoneinfo` (standard library). No naive datetimes are allowed anywhere past the parsing boundary, and a unit test fails if any function returns one.

### 4.3 Service-date resolution for realtime entities

A realtime trip reference must be tied to one service date:

1. If `TripDescriptor.start_date` is present and the trip is active on that date, use it. (BCRTA provides it.)
2. Otherwise, among service dates `d ∈ {obs_local_date − 1, obs_local_date, obs_local_date + 1}` where the trip's `service_id` is active, pick the one whose scheduled trip window `[first_dep − early_tolerance, last_arr + late_tolerance]` contains the observation instant. If several match, pick the smallest distance to the window center. If none match, the trip is unresolved and gets a QC flag.
3. Frequency-based trips (`frequencies.txt`, `exact_times=0`) additionally need `start_time` to identify the instance. If it's missing, the trip is unresolved.

---

## 5. Schema: raw layer

The raw layer is files plus two log tables.

### `static_fetch_log`
| column | type | notes |
|---|---|---|
| feed_id | text | |
| fetched_at | timestamptz | |
| url | text | |
| http_status | int | |
| etag, last_modified | text | Server headers, for change detection |
| zip_sha256 | text | Null if the fetch failed |
| is_new_version | bool | |

### `rt_fetch_log` (one row per HTTP attempt, **including failures and empty responses**)
| column | type | notes |
|---|---|---|
| fetch_id | text PK | |
| feed_id, feed_kind | text | kind ∈ vehicle_positions, trip_updates, service_alerts |
| source | text | `live`, `archive:gtfsrt_io`, … |
| url | text | |
| fetch_started_at, fetch_completed_at | timestamptz | Our clock (NTP-synced host) |
| http_status | int | |
| bytes | int | |
| payload_sha256 | text | Null on failure |
| header_timestamp | bigint | Parsed from the FeedHeader (cheap partial decode) |
| entity_count | int | 0 means a real empty feed, which is different from a failed fetch |
| error | text | |
| collector_version | text | |

### `rt_snapshots` (one row per distinct payload)
| column | type | notes |
|---|---|---|
| payload_sha256 | text PK | |
| feed_id, feed_kind | text | |
| first_fetched_at | timestamptz | **This is the snapshot's `available_at`** |
| last_fetched_at, fetch_count | | The same payload seen repeatedly means a stale feed |
| gtfs_realtime_version, incrementality | text/int | |
| header_timestamp | bigint | |
| raw_path | text | Or null for archive-Parquet-derived rows (see below) |
| provenance | text | `raw_pb` or `archive_parquet` |

**Archive note:** the gtfsrt.io archive didn't allow listing raw snapshots, so backfilled data enters as the archive's flattened Parquet, kept verbatim under `raw/gtfs_rt_archive/`. Those rows get `provenance = archive_parquet` and a synthetic snapshot key (hash of source_file). This is weaker provenance: we can't re-decode the original bytes, and empty snapshots are invisible. Every downstream row inherits the provenance tag, so we can always filter to `raw_pb`-only data.

---

## 6. Schema: normalized static GTFS

Static data is small (BCRTA: 15k stop_times, 9k shape points), so it lives in **native DuckDB tables with declared primary keys and foreign keys**, and is also exported to Parquet. Every table carries `feed_id` and `static_version_id` as leading key columns, so multiple feed versions coexist.

All source columns are read as text first, then cast with explicit rules. Unknown or extra columns are preserved in a `extra_json` column rather than dropped. Non-standard files (BCRTA's `directions.txt`, `calendar_attributes.txt`, `realtime_routes.txt`) stay in raw and are loaded into normalized tables only if a config entry registers them.

| table | primary key | important columns / constraints |
|---|---|---|
| `static_versions` | (feed_id, static_version_id) | zip_sha256, first_seen_at, feed_info start/end dates, feed_version text, validator summary counts, **effective_from / effective_to** (see §9.1) |
| `agency` | (…, agency_id) | agency_timezone NOT NULL; `agency_id` defaults to '' if the feed has a single agency |
| `routes` | (…, route_id) | FK agency; route_type NOT NULL; `route_short_name` trimmed (raw value kept in raw) |
| `trips` | (…, trip_id) | FK route, FK service (soft: calendar or calendar_dates); direction_id, block_id, shape_id nullable |
| `stops` | (…, stop_id) | lat/lon double; location_type; parent_station FK (self) |
| `stop_times` | (…, trip_id, stop_sequence) | arrival_secs, departure_secs INT (nullable for non-timepoint gaps); stop_id FK; shape_dist_traveled; timepoint; pickup/drop_off types. CHECK departure_secs ≥ arrival_secs |
| `calendar` | (…, service_id) | 7 weekday booleans, start_date, end_date |
| `calendar_dates` | (…, service_id, date) | exception_type ∈ {1,2} |
| `shapes` | (…, shape_id, shape_pt_sequence) | lat, lon, shape_dist_traveled |
| `frequencies` | (…, trip_id, start_secs) | if present |
| `feed_info` | (…) | |

### Derived static tables

**`shape_geometry`** (…, shape_id): a projected linestring in a local metric CRS (UTM zone chosen from the feed centroid), total length in meters, and a `dist_unit_factor`. `shape_dist_traveled` units are not standardized in GTFS, so we compute our own meter-based distances and record the ratio against the feed's values as a QC check.

**`stop_on_shape`** (…, trip_id, stop_sequence): each stop's position along the trip's shape in meters (`stop_dist_m`) and its cross-track offset. It is computed by projecting stops **monotonically**: each stop is searched only beyond the previous stop's position, which handles loops where a stop appears twice. The feed's `shape_dist_traveled` is used as a hint when present.

**`service_days`** (feed_id, service_date, service_id, static_version_id): calendar plus calendar_dates expanded, using the governing static version for that date. Example: BCRTA 2026-09-07 (Labor Day) has service_id 1 (Sunday) added and 3 (Weekdays) removed.

**`scheduled_stop_visits`** is the spine. One row per (feed_id, service_date, trip_id, stop_sequence) for every scheduled trip on every service date, with scheduled times as both GTFS seconds and UTC instants, stop_dist_m, is_timepoint, block_id, route/direction, and static_version_id. Every scheduled visit ends up in `stop_events`, even with no evidence, so missing data is explicit instead of silently absent.

---

## 7. Schema: normalized GTFS-Realtime

GTFS-RT is proto2, so field *presence* matters: an absent `delay` is different from `delay = 0`. The decoder uses `HasField` and writes SQL NULL for absent fields. It never writes a default 0.

Every row carries: `feed_id`, `payload_sha256`, `observation_id`, `available_at` (= snapshot `first_fetched_at`), `provenance`.

### `rt_trip_updates` (one row per TripUpdate entity per snapshot)
entity_id, is_deleted, **raw** trip fields (trip_id, route_id, direction_id, start_date, start_time, schedule_relationship), vehicle (id, label), tu_timestamp, trip_delay, trip_properties, and resolved fields:
- `resolved_trip_id`, `resolved_service_date`, `trip_instance_id`
- `resolution_method` ∈ {`direct`, `config_rule:<name>`, `unresolved`}
- `stream` ∈ {`primary`, `detour`, …}, config-defined, so BCRTA's detour entities form their own stream

### `rt_stop_time_updates` (one row per StopTimeUpdate)
observation_id, stu_index, stop_sequence, stop_id, arrival_{time, delay, uncertainty, scheduled_time}, departure_{…}, stu_schedule_relationship, and the resolved `stop_event_id` (via trip_instance + stop_sequence; if stop_sequence is absent, via stop_id only when that stop_id is unique in the trip).

### `rt_vehicle_positions` (one row per VehiclePosition entity per snapshot)
Raw trip fields plus resolved fields as above, vehicle id/label, lat, lon, bearing, speed (m/s), odometer, current_stop_sequence, stop_id, current_status, **vehicle_timestamp**, congestion_level, occupancy fields.

### `vehicle_fixes` (derived, deduplicated)
A vehicle's GPS fix often appears in several consecutive snapshots. We dedupe on (feed_id, vehicle_id, vehicle_timestamp). If vehicle_timestamp is null, we use (vehicle_id, lat, lon, snapshot header_timestamp).
- `available_at` = earliest snapshot containing the fix
- `seen_count`; `fix_age_at_fetch_s` = available_at − vehicle_timestamp
- `conflict_flag` if the same (vehicle, timestamp) appears with different coordinates or trips (a contradictory observation)

### `prediction_history` (change-only compression)
One row per (stop_event_id, stream, source_field) **each time the predicted value changes**: predicted_arrival, predicted_departure, uncertainties, `valid_from` (available_at of first snapshot with this value), `valid_to` (available_at of the first snapshot with a different value, or the stop's disappearance). BCRTA's 4M Trip Update rows per day compress to a small fraction of that, and the full history remains reconstructible for Phase 3 prediction-accuracy work.

---

## 8. Schema: reconstructed layer

### 8.1 `trip_instances`
| column | notes |
|---|---|
| trip_instance_id PK | |
| feed_id, service_date, trip_id, start_time | |
| static_version_id, route_id, direction_id, block_id, shape_id | From static; null for added trips without a static match |
| origin | `scheduled` or `rt_added` |
| operational_status | `operated`, `canceled`, `partially_operated`, `no_data`, `contradictory` |
| rt_schedule_relationships | Distinct values seen across snapshots, with first/last available_at |
| has_detour_stream | bool |
| first_evidence_at, last_evidence_at | |
| run_id, algorithm_version | |

### 8.2 `vehicle_trip_assignments`
(trip_instance_id, vehicle_id, assigned_from, assigned_to, source ∈ {vp, tu}, fix_count). This handles reassignment: a trip can have several vehicles over time, and a vehicle serves many trips per block.

### 8.3 `stop_events` (the main output)

Key: `stop_event_id` = (trip_instance_id, stop_sequence). One row for every scheduled visit plus visits from added trips.

| group | columns |
|---|---|
| identity | stop_event_id, feed_id, service_date, trip_id, trip_instance_id, stop_sequence, stop_id, route_id, direction_id, block_id, vehicle_id, static_version_id |
| schedule | scheduled_arrival_secs, scheduled_departure_secs (GTFS seconds), scheduled_arrival_utc, scheduled_departure_utc, is_timepoint, stop_dist_m, is_first_stop, is_last_stop |
| status | event_status ∈ {`served`, `passed_no_stop_info`, `skipped`, `canceled`, `no_evidence`, `contradictory`} |
| **passage** | passage_utc, passage_method, passage_uncertainty_s, passage_delay_s |
| **arrival** | arrival_utc, arrival_method, arrival_uncertainty_s, arrival_delay_s |
| **departure** | departure_utc, departure_method, departure_uncertainty_s, departure_delay_s |
| dwell | dwell_s (only if both arrival and departure come from dwell-capable methods) |
| leakage control | **knowable_at**: the earliest instant at which the selected evidence was available |
| provenance | evidence_count, has_conflict, qc_flags (list), provenance (raw_pb / archive_parquet / mixed), run_id, algorithm_version |

**Changes from the originally proposed columns, and why:**

- *`predicted_arrival/departure` removed from stop_events.* A stop visit has hundreds of predictions over time, so a single "predicted" column is ambiguous (which one?) and invites leakage. Predictions live in `prediction_history` with validity intervals.
- *`observed_*` + `actual_*` replaced by value + method.* Two parallel column sets force every consumer to reimplement the precedence logic. Instead, each time has one value and a `*_method` enum that says exactly what kind of evidence produced it (§11). "Observed" is a property of the method, not a separate column.
- *`passage_*` added.* For most BCRTA stops the only defensible quantity is when the bus passed the stop. Forcing that into arrival or departure would be manufacturing precision.
- *`confidence` replaced by `*_uncertainty_s`.* A seconds-denominated half-width is interpretable, comparable across methods, and usable as a label weight. A 0–1 score is none of those.
- *`source_observation_id` replaced by the `stop_event_evidence` table.* One time is often derived from two or more observations (two bracketing GPS fixes).
- *`created_at/updated_at` replaced by `run_id` + `algorithm_version`.* Wall-clock timestamps make output non-deterministic. The run ledger records when runs happened.
- *`knowable_at` added.* This is essential for leakage-safe feature building (§15).

Delays are computed as `time_utc − scheduled_utc` in whole seconds. Positive means late. `passage_delay_s` uses scheduled_departure (at BCRTA, arrival equals departure in the schedule for nearly all stops).

### 8.4 `stop_event_evidence`
Every candidate considered, not just the winner: stop_event_id, time_kind (arrival/departure/passage), method, candidate_utc, uncertainty_s, knowable_at, observation_ids (list), parameters (json, such as bracketing distances), **selected** (bool), rejection_reason. This is what lets you reproduce and audit any label later.

### 8.5 `qc_results`
(run_id, feed_id, service_date, check_name, severity, metric_value, threshold, passed, details_json).

---

## 9. Static GTFS → realtime join rules

### 9.1 Which static version governs an observation?

Each static version gets `effective_from` = max(first_seen_at date, feed_info.feed_start_date or calendar min) and `effective_to` = the next version's effective_from − 1 day. A realtime observation joins to the version governing its **resolved service date**. For BCRTA: Fall 2026 v1.01 governs service dates from 2026-08-23. July–August data needs the summer version, which isn't loaded yet, so those service dates are flagged `no_static_version` and skipped rather than joined to the wrong schedule.

### 9.2 Join keys

| realtime entity | join path | notes |
|---|---|---|
| TripUpdate / VehiclePosition trip | (feed_id, static_version_id, trip_id) → trips; + service_date → trip_instance | route/direction/block always come from static; the realtime route_id is only a cross-check |
| TripUpdate with blank trip_id | config trip-resolution rules (regex on entity_id, then vehicle + time matching) | BCRTA detour rule; `resolution_method` records which rule fired |
| ADDED / NEW trip | new trip_instance with origin=rt_added; stops from STUs | no schedule means no delays; kept for completeness |
| StopTimeUpdate | trip_instance + stop_sequence → scheduled_stop_visit | fallback: stop_id if unique within the trip; otherwise unresolved |
| STU stop_id ≠ scheduled stop_id at that sequence | kept with `stop_mismatch` flag | could be a detour or bad data |
| VehiclePosition stop fields | stop_sequence first, then stop_id with the same uniqueness rule | unused at BCRTA (always empty) |
| vehicle_id | free text; no static table | vehicle continuity comes from `vehicle_trip_assignments` |

---

## 10. Stop-event reconstruction algorithm

The unit of work is **one service date for one feed**. Within it, the unit is **one trip instance**, which is embarrassingly parallel.

### Step 1: Build trip instances
Take all scheduled trips from `scheduled_stop_visits`, then add realtime ADDED/NEW trips. Collect every Trip Update and Vehicle Position referencing each instance, from the service date's UTC window plus padding (the service day can span two or three UTC dates).

### Step 2: Determine trip status
- CANCELED in Trip Updates, and no GPS progress along the shape: `canceled`.
- CANCELED but GPS shows the vehicle progressing along this trip's shape: `contradictory` (flagged; GPS evidence still reconstructed, since movement is physical evidence and a cancellation is a claim).
- No evidence at all: `no_data`. Every stop event becomes `no_evidence`.

### Step 3: Assign vehicles and clean fixes
For each instance, take `vehicle_fixes` whose resolved trip_instance matches. Then:
- Drop fixes with `fix_age_at_fetch_s > max_fix_age` (stale), or with vehicle_timestamp in the future beyond clock tolerance.
- Sort by vehicle_timestamp (**not** fetch order, which fixes out-of-order delivery).
- Drop physically impossible jumps (implied speed > `max_speed_mps`).
- If two vehicles report the same trip at overlapping times, keep the vehicle whose fixes project consistently onto the shape and flag `multi_vehicle`.

### Step 4: Linear referencing (project GPS onto the shape)
For each fix, find its distance along the trip's shape (`dist_m`) and cross-track error:
- Candidates are all shape segments within `max_cross_track_m` (default 50 m).
- Choose the candidate consistent with forward progress: a monotone path search over consecutive fixes (a small dynamic program: minimize cross-track error plus a penalty for backward movement or implausible advance). This handles loops and routes that double back on the same street.
- Fixes with no candidate within tolerance are **off-route**. Runs of off-route fixes mark a probable detour segment.
- Then enforce monotonicity: backward movement under `jitter_tolerance_m` (default 25 m) is clamped. Larger backward moves are flagged and those fixes are excluded.

### Step 5: Generate candidate evidence per stop
For each stop visit (in stop_sequence order) at `stop_dist_m` with radius `r` (default 30 m):

- **Producer status** (only if the feed populates it): `current_status = STOPPED_AT` for this stop gives arrival between the last not-stopped fix and the first STOPPED_AT fix, and departure between the last STOPPED_AT fix and the next fix.
- **GPS dwell:** ≥ `min_dwell_fixes` (default 2) fixes within ±r of stop_dist_m with speed ≤ `stationary_speed_mps`. Arrival is interpolated at the **entry** of the radius window (stop_dist_m − r), departure at the **exit** (stop_dist_m + r), each between its two bracketing fixes.
- **GPS interpolated passage:** find the last fix before stop_dist_m and the first fix at or after it. If the time gap is ≤ `max_interp_gap_s` (default 120 s), linearly interpolate the time at stop_dist_m. Uncertainty is half the gap, plus a term for the distance traveled.
- **Trip Update stop dropout:** the stop is present in snapshot S_k and absent from S_k+1 of the same stream, while the trip entity persists in S_k+1 and the dropout is not explained by a whole-trip disappearance or feed outage (checked via `rt_fetch_log`). Passage is the midpoint of [S_k.available_at, S_k+1.available_at], plus a **calibrated bias correction** estimated per feed from stops where GPS evidence also exists. Uncertainty is half the bracket plus the calibrated spread.
- **Inter-stop interpolation (bounded):** a stop has none of the above, but both the nearest preceding and following stops have GPS-based times within `max_interp_span_s`. Interpolate by scheduled running time proportions. This is the lowest tier and is always flagged.

**Terminal stops:** at the first stop, only departure is defined (arrival there is layover, not service). Departure is the radius exit after the last stationary fix. At the last stop, only arrival is defined.

### Step 6: Select, then check consistency
Apply the evidence hierarchy (§11) per time kind. Then verify times are non-decreasing along stop_sequence. For any violation, drop the lower-tier value (ties go to the larger uncertainty), record the rejection in `stop_event_evidence`, and add a `non_monotone` flag. Implied speeds between consecutive stops above `max_speed_mps` are also flagged.

### Step 7: Status, delays, knowable_at, write
Set `event_status`, compute delays, and set `knowable_at` = max(available_at) over the observations used by the selected evidence (for GPS interpolation that's the *later* bracketing fix; for dropout it's S_k+1). Write the partition atomically.

---

## 11. Evidence hierarchy

It is deterministic. For each stop event and each time kind, the highest-ranked available method wins. Ties are broken by smaller uncertainty, then earlier knowable_at, then lowest observation_id.

| rank | method code | produces | label class | BCRTA availability |
|---|---|---|---|---|
| 1 | `producer_stop_status` | arrival, departure, passage | **observed** (sampled status transitions) | none (field empty) |
| 2 | `gps_dwell` | arrival, departure, passage | inferred, strong | ~12% of visits |
| 3 | `gps_interpolated_passage` | passage only | inferred, strong | majority of visits (to be measured) |
| 4 | `tu_stop_dropout` | passage only | inferred, weak; bias-calibrated | most visits, as a fallback and cross-check |
| 5 | `inter_stop_interpolation` | passage only | inferred, weakest | gaps only |
| — | `none` | nothing | time left NULL | explicit `no_evidence` |

Rules that never bend:

- **A prediction is never promoted to an actual time.** A Trip Update time that is later "confirmed" by the stop dropping out still becomes `tu_stop_dropout` evidence, bracketed by snapshot times, not by the predicted value.
- **Passage time is defined when any tier produces a time.** When dwell evidence exists, passage equals departure. Arrival and departure are defined **only** by tiers 1–2.
- **Methods are never mixed within one time.** One value comes from exactly one method, and all candidates are kept in the evidence table.
- **Tier 4's bias correction** is estimated from out-of-sample days (never the day being reconstructed), stored as a versioned calibration artifact, and referenced by run_id.
- A feed or agency can disable tiers via config (for example, tier 5 off by default until validated).

---

## 12. Edge-case handling

| case | detection | handling |
|---|---|---|
| **Missing STUs** | a stop never appears in any Trip Update for an operated trip | no TU evidence; GPS tiers still apply |
| **Repeated snapshots** | identical payload_sha256 | stored once; fetch_count incremented; `stale_feed` QC if header_timestamp doesn't advance for > N minutes |
| **Duplicate entities within a snapshot** | same trip_instance twice in one payload | keep both rows; evidence generation takes the entity with the later tu_timestamp; flag `dup_entity` |
| **Duplicate GPS fixes** | same (vehicle, vehicle_timestamp) | deduped in `vehicle_fixes`; earliest available_at kept |
| **Stale predictions** | tu_timestamp or header_timestamp far behind fetch time | excluded from dropout evidence (a stale feed can't show a stop disappearing); kept in prediction_history with the staleness recorded |
| **Out-of-order messages** | snapshot header_timestamp decreases between fetches | order by available_at for "what was known when"; order by vehicle_timestamp for physics; flagged |
| **Contradictory observations** | same fix with different coordinates; CANCELED but moving; stop_id mismatch at a sequence | kept; `contradictory` status or flag; physics (GPS) outranks claims (schedule_relationship) |
| **Trip reassignment** | vehicle for a trip_instance changes | `vehicle_trip_assignments` split by time; each vehicle's fixes used for its interval |
| **Canceled trips** | TU CANCELED | `canceled` status; stop events kept with NULL times and `canceled` status (not `no_evidence`) |
| **Added trips** | TU ADDED/NEW, or unknown trip_id | trip_instance origin=rt_added; passage times reconstructed if a shape can be inferred; no delays |
| **Skipped stops** | STU SKIPPED | event_status `skipped`; physical passage (if GPS shows the bus went by) kept in the evidence table but not as a label |
| **Detours** | off-route GPS runs; config detour stream; STU stop mismatches | stops inside the off-route span → `no_evidence` + `detour` flag; detour-stream TU evidence is used only for stops it references that are on the actual path |
| **Collector outage** | gap in rt_fetch_log attempts | evidence brackets spanning an outage are rejected (not interpolated across) |
| **Empty feed** | successful fetch with entity_count = 0 | treated as "no vehicles," not an outage (only knowable from our own raw logs) |
| **Midnight / >24:00** | GTFS seconds ≥ 86400 | noon-minus-12h rule; synthetic tests |
| **DST** | service dates on transition days | same rule; synthetic tests on both 2026 transitions |
| **Missing stop_sequence in realtime** | STU without stop_sequence | stop_id fallback only if unique in the trip, else unresolved |
| **Missing shape** | trip without shape_id | build a straight-line path through stop coordinates; flag `synthetic_shape`; lower uncertainty confidence |

---

## 13. Data quality and validation

Checks have a **severity**: `block` stops the stage for that partition, `warn` records and continues. All results land in `qc_results`, and a daily Markdown/HTML report summarizes them.

**Static (per version):**
- The MobilityData gtfs-validator report is stored. Any ERROR-level notice triggers `warn` (not `block`, since many real feeds have errors and we'd rather ingest and flag).
- Our own checks: primary-key uniqueness; referential integrity; stop_times times non-decreasing along stop_sequence; shape_dist_traveled monotone; each stop within 100 m of its trip's shape (else `synthetic_shape` or a flag); every trip has an active service date somewhere; timezone valid.

**Realtime (per service date):**
- Fetch success rate and the longest outage.
- Snapshot cadence (p50/p95 interval) versus the configured poll rate.
- trip_id match rate against static (**block** if < 90%, which usually means the wrong static version).
- stop_sequence/stop_id agreement rate.
- Fraction of entities unresolved.
- Fix age distribution.
- Share of `stale_feed` minutes.

**Reconstruction (per service date):**
- Coverage: the share of scheduled visits by final method, and the share of operated trips with ≥ 80% of stops timed.
- Delay sanity: |delay| > 2 h is flagged per event; the median delay per route is within plausible bounds.
- Monotonicity violations per trip.
- **Method agreement:** for stops with both GPS and dropout evidence, the distribution of (dropout − GPS). This is both a QC metric and the calibration input.
- Implied speeds between stops.
- Row-count invariant: `stop_events` rows = scheduled visits + added-trip visits. No stop visit may silently disappear.

**Tests:** unit tests per module (time math, projection, each evidence method, the selection rule), property-based tests for time conversion and monotone projection, and integration tests that run the full pipeline on synthetic feeds with known ground truth (§16 is the first).

---

## 14. Idempotency and reproducibility

1. **Raw is content-addressed and append-only.** Re-downloading the same bytes is a no-op (apart from a fetch_log row). Nothing in raw is ever overwritten.
2. **Deterministic IDs** (§3) mean re-running normalization produces identical keys.
3. **Partition-level replace.** Every derived stage writes one (feed_id, service_date) partition to a temp directory, then atomically renames it over the old one. A crash never leaves half a partition. Re-running replaces rather than appends, so duplicates can't arise.
4. **Stable ordering.** Output rows are sorted by primary key before writing, so identical inputs give byte-identical Parquet (verified by a test that hashes outputs across two runs).
5. **Run ledger.** `runs` (run_id, stage, feed_id, service_date, algorithm_version, config_hash, input_manifest_hash, started_at, finished_at, status). A stage is skipped if a successful run with the same run_id exists, unless forced.
6. **Versioned logic.** `algorithm_version` is bumped whenever reconstruction semantics change. Old outputs can be regenerated from raw for comparison.
7. **No wall-clock values in derived data**, apart from the run ledger.

---

## 15. Leakage prevention and prediction targets

### 15.1 The rule

A model prediction is made at a **prediction time** `t` (for example, when the bus departs stop k). A feature may use an observation only if its `available_at ≤ t`. A reconstructed stop event may be used as a feature only if its `knowable_at ≤ t`.

The data model supports this directly:
- Every normalized realtime row has `available_at`.
- Every stop event has `knowable_at`, which is the moment it *could* have been computed, not the moment the bus passed.
- `prediction_history` has validity intervals, so "the agency's prediction at time t" is an interval lookup.

In Phase 2, features are built only through **as-of joins** on these columns, never through plain joins on trip/stop. Aggregates like historical route performance are computed from service dates strictly before the prediction's service date. The train/validation/test split is by **service date** (contiguous blocks), never random rows. Random splits leak through same-day correlation.

### 15.2 Which targets the data supports

| target | definition | supported by | recommendation |
|---|---|---|---|
| **A. Passage delay at stop N** | passage_delay_s at N, predicted at t = departure from stop k < N | nearly every served stop | **Primary target** |
| B. Delay change | passage_delay(N) − passage_delay(k) | same | Strong secondary; often easier to learn, and removes the "already late" component |
| C. Departure delay at N | departure_delay_s | only dwell-evidence stops (~12% at BCRTA) | Too sparse for BCRTA; fine for feeds with stop status |
| D. Arrival delay at N | arrival_delay_s | same | Same |
| E. Timepoint-only passage delay | A restricted to is_timepoint | 21% of visits | Cleaner labels, since non-timepoint schedule times are minute-rounded interpolations |

Label hygiene: train only on events with methods of rank ≤ 3 by default, optionally weighted by 1/uncertainty. Tier-4 and tier-5 labels are excluded unless explicitly enabled. Skipped, canceled, contradictory, and detour-flagged events are never labels.

---

## 16. Worked synthetic example

**Parameters:** r = 30 m, min_dwell_fixes = 2, stationary speed ≤ 0.5 m/s, max_interp_gap_s = 120. For simplicity, tier-4 bias correction = 0.

### Schedule (service date 2026-09-16, trip `T100`, vehicle 7405, times EDT = UTC−4)

| stop_sequence | stop_id | stop_dist_m | scheduled arr = dep | timepoint |
|---|---|---|---|---|
| 0 | A | 0 | 08:00:00 | yes |
| 1 | B | 800 | 08:03:00 | no |
| 2 | C | 1600 | 08:06:00 | no |
| 3 | D | 2400 | 08:09:00 | yes |

### GPS fixes (already projected onto the shape)

| vehicle_timestamp | dist_m | speed m/s | note |
|---|---|---|---|
| 08:00:00 | 0 | 0 | waiting at A |
| 08:00:20 | 5 | 0 | still at A |
| 08:00:40 | 120 | 8 | moving |
| 08:01:00 | 300 | 9 | |
| 08:01:20 | 480 | 9 | |
| 08:01:40 | 660 | 6 | |
| 08:02:00 | 790 | 0 | at B |
| 08:02:20 | 800 | 0 | at B |
| 08:02:40 | 810 | 0 | at B |
| 08:03:00 | 900 | 5 | moving |
| — | — | — | **GPS gap 08:03:00 → 08:08:00 (300 s)** |
| 08:08:00 | 2300 | 4 | |
| 08:08:20 | 2390 | 0 | at D |
| 08:08:40 | 2400 | 0 | at D |

### Trip Update snapshots (excerpt; every 20 s)

| snapshot available_at | stops listed | prediction for C | prediction for D |
|---|---|---|---|
| 08:02:03 | B, C, D | 08:05:40 | 08:08:50 |
| 08:05:03 | C, D | 08:06:30 | 08:09:20 |
| 08:06:43 | C, D | 08:06:55 | 08:09:25 |
| 08:07:03 | D | — | 08:09:10 |

These predictions go into `prediction_history` (four distinct values for C, each with a validity interval). They are **not** used as stop-event times.

### Reconstruction, stop by stop

**A (first stop, departure only).** Stationary fixes at 08:00:00 and 08:00:20 within 30 m, so this is **gps_dwell**. Exit of radius at 30 m falls between 08:00:20 (5 m) and 08:00:40 (120 m): 20 s × (30 − 5)/(120 − 5) = 4.3 s, giving **08:00:24**. Uncertainty ±10 s. Departure delay **+24 s**. Arrival is NULL (origin terminal).

**B (dwell).** Three stationary fixes within 770–830 m, so this is **gps_dwell**.
Arrival = entry at 770 m, between 08:01:40 (660) and 08:02:00 (790): 20 × 110/130 = 16.9 s, giving **08:01:57**, delay **−63 s**.
Departure = exit at 830 m, between 08:02:40 (810) and 08:03:00 (900): 20 × 20/90 = 4.4 s, giving **08:02:44**, delay **−16 s**.
Passage = departure. Dwell = 47 s.

**C (GPS gap).** The bracketing fixes are 300 s apart, which is over the 120 s limit, so **gps_interpolated_passage is rejected**. (It would have said 08:05:30. The evidence table keeps it with `rejection_reason = gap_exceeds_max`.) Tier 4: C is present at 08:06:43 and absent at 08:07:03 while the trip persists, so passage is the bracket midpoint **08:06:53**, uncertainty ±10 s. Passage delay **+53 s**. Arrival and departure are NULL. Note the 83 s disagreement between the rejected GPS interpolation and the dropout. This is exactly why long-gap interpolation is disallowed.

**D (last stop, arrival only).** Stationary fixes at 08:08:20 and 08:08:40, so this is **gps_dwell**. Entry at 2370 m, between 08:08:00 (2300) and 08:08:20 (2390): 20 × 70/90 = 15.6 s, giving **08:08:16**, delay **−44 s**.

### Resulting `stop_events` rows (local time shown; stored in UTC)

| seq | stop | status | sched | arrival (method) | departure (method) | passage (method) | arr delay | dep delay | passage delay | ±s | knowable_at |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | A | served | 08:00:00 | NULL | 08:00:24 (gps_dwell) | 08:00:24 (gps_dwell) | NULL | +24 | +24 | 10 | ≈08:00:43¹ |
| 1 | B | served | 08:03:00 | 08:01:57 (gps_dwell) | 08:02:44 (gps_dwell) | 08:02:44 (gps_dwell) | −63 | −16 | −16 | 10 | ≈08:03:03 |
| 2 | C | passed_no_stop_info | 08:06:00 | NULL | NULL | 08:06:53 (tu_stop_dropout) | NULL | NULL | +53 | 10 | 08:07:03 |
| 3 | D | served | 08:09:00 | 08:08:16 (gps_dwell) | NULL | 08:08:16 (gps_dwell) | −44 | NULL | −44 | 10 | ≈08:08:43 |

¹ knowable_at = available_at of the later bracketing fix (fix time + ~3 s fetch lag).

A leakage illustration: a model predicting C's delay at 08:03:05 may use B's departure delay (−16 s, knowable 08:03:03) but **not** C's own label or D's anything. A feature built from "latest known delay on this trip" at 08:03:05 correctly returns −16 s.

This example becomes the first integration test fixture, with these exact expected rows.

---

## 17. Technology stack

| need | choice | why (and what was rejected) |
|---|---|---|
| Language | **Python 3.11+** | GTFS-RT bindings, geospatial tools, and LightGBM later all live here |
| Protobuf decoding | **gtfs-realtime-bindings** (official) + pinned `.proto` | canonical, and keeps presence semantics |
| Storage format | **Parquet** (Hive-partitioned) | columnar, portable, inspectable with any tool, cheap to rewrite per partition |
| Query/compute engine | **DuckDB** | runs in-process with no server; reads Parquet directly; enough for BCRTA-scale data (≈15k stop events/day, ≈50k fixes/day) and far beyond. **PostgreSQL rejected for Phase 1**: it adds a server to operate, and nothing here needs concurrent writers or serving. It can be added later if an API is needed. |
| Per-trip numeric work | **NumPy** + **Shapely 2 / pyproj** | vectorized projection and interpolation. Shapely for linear referencing, pyproj for the metric CRS |
| DataFrames | **Polars** only where Python-side logic needs frames | one library, not two. Most set logic is DuckDB SQL |
| Config | **Pydantic** models over YAML | validated, typed configuration; agency quirks isolated |
| CLI | **Typer** | `tdp ingest-static`, `tdp collect`, `tdp reconstruct --date` … |
| Logging | **structlog** (JSON) | structured, greppable, with run_id in every line |
| Tests | **pytest** + **hypothesis** | property tests for time math and projection |
| Static validation | MobilityData **gtfs-validator** (Java CLI, invoked as a subprocess) | canonical rules without reimplementing them |
| Scheduling | **cron / launchd** for the collector; CLI for batches | **Airflow/Prefect rejected**: a handful of daily jobs don't justify an orchestrator. Revisit if many feeds or cloud deployment arrive |
| Transformations | Python modules + SQL files, not dbt | reconstruction is algorithmic, not only SQL. **dbt rejected for Phase 1**; it could suit Phase 2 feature marts |
| Packaging | `pyproject.toml` + `uv` (or pip) + optional **Docker** image for the collector | the collector must run unattended; Docker makes it portable to a small server |
| Object storage | local filesystem first; path abstraction allows S3/GCS later | no cloud dependency needed for correctness |

---

## 18. Project structure

```
transit-delay-prediction/
├── pyproject.toml
├── README.md
├── Makefile                      # common commands
├── config/
│   ├── pipeline.yaml             # global thresholds, paths, algorithm defaults
│   └── feeds/
│       └── bcrta.yaml            # everything agency-specific
├── proto/gtfs-realtime.proto     # pinned
├── src/tdp/
│   ├── config/                   # pydantic models, loader, config hashing
│   ├── common/                   # ids.py, logging.py, paths.py, parquet_io.py, runs.py
│   ├── timeutil/                 # gtfs_time.py (secs <-> instants), service_dates.py
│   ├── static/                   # fetch.py, store_raw.py, validate.py, normalize.py,
│   │                             # versions.py, service_days.py, spine.py, shapes.py
│   ├── realtime/
│   │   ├── collector.py          # live polling -> raw + fetch_log
│   │   ├── archive_adapters/     # gtfsrt_io.py (one module per archive source)
│   │   ├── decode.py             # pb -> typed records (presence-aware)
│   │   ├── resolve.py            # trip identity + service date + config rules
│   │   ├── normalize.py
│   │   └── prediction_history.py
│   ├── reconstruct/
│   │   ├── trip_instances.py
│   │   ├── assignments.py
│   │   ├── fixes.py              # cleaning, dedupe, ordering
│   │   ├── linear_ref.py         # monotone projection onto shapes
│   │   ├── evidence/             # producer_status.py, gps_dwell.py, gps_passage.py,
│   │   │                         # tu_dropout.py, interstop.py
│   │   ├── select.py             # hierarchy + consistency pass
│   │   └── events.py             # assemble + write stop_events / evidence
│   ├── quality/                  # checks.py, calibration.py, report.py
│   └── cli.py
├── sql/                          # versioned SQL used by stages (views, checks)
├── tests/
│   ├── unit/
│   ├── integration/
│   └── fixtures/synthetic/       # tiny GTFS + generated .pb with known truth
├── notebooks/                    # exploration only; never imported by src/
└── data/                         # gitignored; layout in §3
```

Your existing `src/fetch_realtime.py` becomes the seed of `realtime/archive_adapters/gtfsrt_io.py`.

---

## 19. Agency configuration (BCRTA example)

```yaml
feed_id: bcrta
agency_timezone_override: null            # use agency.txt
static:
  url: <BCRTA GTFS zip URL>
  register_extension_files: []            # directions.txt etc. stay raw-only
realtime:
  vehicle_positions: { url: https://www.buztrakr.com/gtfs-rt/vehiclepositions, poll_seconds: 20 }
  trip_updates:      { url: https://www.buztrakr.com/gtfs-rt/tripupdates,      poll_seconds: 20 }
  service_alerts:    { url: <alerts URL>,                                      poll_seconds: 60 }
  archive_sources:
    - adapter: gtfsrt_io
      feed_url_keys: [vehicle_positions, trip_updates, service_alerts]
trip_resolution_rules:
  - name: detour_entity
    applies_when: { trip_id_blank: true }
    entity_id_regex: '^detour_\d+_trip_(?P<trip_id>.+)$'
    assign_stream: detour
capabilities:                             # what this feed actually provides (verified by QC)
  vp_stop_status: false
  tu_separate_arrival_departure: false
  tu_uncertainty: false
reconstruction_overrides:
  stop_radius_m: 30
  max_interp_gap_s: 120
  enable_tiers: [gps_dwell, gps_interpolated_passage, tu_stop_dropout]
```

A new agency is a new YAML file. If it needs a quirk that no rule type supports, a new **generic** rule type is added to the core (for example, "trip_id from entity_id regex"). It never becomes an `if feed_id == ...` branch.

---

## 20. Implementation plan

| step | deliverable | done when |
|---|---|---|
| 0 | Skeleton, config models, logging, IDs, **time utilities** | property tests pass for >24:00, both 2026 DST dates, and round-trips |
| 1 | **Live collector** (runs unattended) | starts writing raw `.pb` + fetch_log for BCRTA. Start this early: it's the only source of true raw data and empty-snapshot visibility, and every day not collected is lost |
| 2 | Static ingest, versions, service_days, spine, shape/stop projection | BCRTA Fall 2026 loads with all checks green; Labor Day expands correctly |
| 3 | Realtime decode + normalize + resolve (live raw and archive Parquet) | trip match ≥ 99% on 2026-09-16; detour rule resolves the 36 entities; prediction_history built |
| 4 | Reconstruction tiers 2–3 (GPS) + selection + stop_events | synthetic §16 test passes exactly; BCRTA day reconstructed; coverage report produced |
| 5 | Tier 4 (dropout) + calibration against GPS; tier 5 behind a flag | agreement metrics reported; bias artifact versioned |
| 6 | QC report + determinism test (two runs, identical hashes) | report reviewed with you |
| 7 | Backfill 2026-08-23 → present | per-day QC stored; summary of label coverage by method |

Phase 2 (features and LightGBM) starts only after you've reviewed step 7's output.

---

## 21. Decisions needing your approval

1. **Primary label = passage time/delay**, with arrival and departure only where dwell is observed.
2. **Default thresholds:** stop radius 30 m, max GPS interpolation gap 120 s, ≥ 2 stationary fixes for dwell. These will be revisited after step 4's data.
3. **Tier 4 (Trip Update dropout)** enabled for BCRTA, with calibration. **Tier 5** disabled by default.
4. **Scope:** start from service date 2026-08-23 (the Fall schedule). Summer data waits until the summer static version is sourced.
5. **Stack:** Python + DuckDB + Parquet, with no server database, orchestrator, or dbt in Phase 1.
6. **Start the live collector first** (step 1), before the rest of the pipeline.
