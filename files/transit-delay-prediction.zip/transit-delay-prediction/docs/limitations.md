# Limitations

Read this before drawing conclusions from the outputs.

## Measurement

1. **Actual times are estimates.** They come from GPS positions reported roughly every 20 seconds,
   not from the bus's door sensors, fare box, or operator log. Typical error is 10 to 30 seconds;
   reports round to the nearest minute.
2. **Passing is not stopping.** If GPS did not catch the bus standing at a stop, only the moment it
   passed is known. At timepoints this is still the moment it left, but not a door-closing time.
3. **Arrival and departure are separate only for a minority of stops** (about 14% of stop visits for
   BCRTA), where GPS caught the bus standing still.
4. **Feed quality varies by agency.** Some feeds report stop status, which improves accuracy; BCRTA's
   does not. Positions may be delayed, rounded, or missing.

## Missing data

5. **Missing data is not random.** Trackers switched off, collection outages, detours off the mapped
   route, and vehicles without a trip assignment all produce unmeasured departures. If these cluster
   on certain routes, times, or vehicles, percentages can be biased toward the measured cases. Always
   check the coverage chart and `daily_summary.csv`.
6. **Canceled trips and skipped stops look like missing data** because Trip Updates are not used yet.
7. **The historical archive is third-party.** gtfsrt.io's completeness has not been verified, and its
   daily files cannot distinguish "no buses were running" from "the archive was not collecting".
   The planned live collector will record this directly.

## Scope

8. **One schedule version per run.** Dates outside that schedule's calendar are skipped. Periods
   spanning a schedule change must be processed separately with the right schedule file each time.
9. **Frequency-based service** (`frequencies.txt`) is not supported yet.
10. **Scale**: designed for small and mid-size agencies. Very large agencies will work but slowly.

## Interpretation

11. **Small samples are unstable.** Values based on fewer than 5 days are marked in reports.
12. **Thresholds matter.** Early/late definitions differ between agencies and studies; results change
    with the thresholds in the configuration file.
13. **History is not a forecast.** "Typical" values are a simple historical baseline. They cannot
    anticipate unusual events such as crashes, breakdowns, weather, or special events, and service
    patterns change with schedule changes and seasons (for BCRTA, the university semester).
