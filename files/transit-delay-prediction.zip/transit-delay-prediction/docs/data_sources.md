# Data sources

## GTFS static (the schedule)

Each agency publishes its schedule as a zip of text files (`stops.txt`, `trips.txt`,
`stop_times.txt`, ...). Find it on the agency's website, [Mobility Database](https://mobilitydatabase.org),
or [Transitland](https://www.transit.land). Transitland also keeps older versions, which you need
when analysing past dates. **Use the version that was in effect on the dates you study**; the
program warns when realtime trip IDs do not match the schedule.

For BCRTA, the Fall 2026 schedule (`feed_info.txt`: "Fall 2026 Version 1.01") is valid from
23 August 2026.

## GTFS-Realtime vehicle positions (what happened)

Agencies publish a live Vehicle Positions feed, but most do not keep its history. The tool works
with whatever history you have, passed with `--rt`:

1. **Your own saved snapshots** (`.pb` files). Collecting them yourself is the most reliable
   source; a built-in collector is planned.
2. **Your own export** from another system, as CSV or Parquet, with column names mapped in the
   config file.
3. **The agency's archived AVL (automatic vehicle location) data**, exported to CSV.
4. **Optionally, a public archive** such as gtfsrt.io (below), which the tool can download from
   when `--rt` is not given.

## The gtfsrt.io archive

gtfsrt.io is a third-party service that records public GTFS-Realtime feeds and publishes them free,
without a login. At the time of writing its data inventory listed feeds for around twenty agencies,
including BCRTA from 10 July 2026 onward. This project is not affiliated with it, and its
availability and completeness are outside our control.

### How files are organized

One Parquet file per feed per **UTC** date, with one row per vehicle per snapshot:

```
http://parquet.gtfsrt.io/vehicle_positions/date=<YYYY-MM-DD>/base64url=<KEY>/data.parquet
```

`<KEY>` is the agency's live feed URL encoded as URL-safe base64 without `=` padding. Raw
protobuf snapshots are published under `http://protobuf.gtfsrt.io/...` with the same pattern plus an
hour folder and a timestamped file name, but these could not be listed publicly when this project
was written, so the program uses the Parquet files.

### Worked example (BCRTA)

BCRTA's live Vehicle Positions feed is `https://www.buztrakr.com/gtfs-rt/vehiclepositions`.

```python
import base64
url = "https://www.buztrakr.com/gtfs-rt/vehiclepositions"
key = base64.urlsafe_b64encode(url.encode()).decode().rstrip("=")
# key == "aHR0cHM6Ly93d3cuYnV6dHJha3IuY29tL2d0ZnMtcnQvdmVoaWNsZXBvc2l0aW9ucw"
```

The file for UTC date 22 September 2026 is therefore:

```
http://parquet.gtfsrt.io/vehicle_positions/date=2026-09-22/base64url=aHR0cHM6Ly93d3cuYnV6dHJha3IuY29tL2d0ZnMtcnQvdmVoaWNsZXBvc2l0aW9ucw/data.parquet
```

You can inspect it directly with DuckDB:

```sql
INSTALL httpfs; LOAD httpfs;
SELECT vehicle_id, trip_id, start_date, latitude, longitude, timestamp, fetch_timestamp
FROM read_parquet('http://parquet.gtfsrt.io/vehicle_positions/date=2026-09-22/base64url=aHR0cHM6Ly93d3cuYnV6dHJha3IuY29tL2d0ZnMtcnQvdmVoaWNsZXBvc2l0aW9ucw/data.parquet')
LIMIT 10;
```

`python -m tdp.history` builds these addresses and downloads the files for you, from the
`archive.vehicle_positions_url` setting in the feed's configuration file.

### Things to know

* **Dates are UTC.** A BCRTA service day (Eastern time) spans two UTC files; the evening's trips are
  in the next UTC date's file. The history command downloads both.
* **Snapshot rate**: for BCRTA the archive captured a snapshot about every 20 seconds.
* **Gaps**: an hour with no rows can mean no buses were running or that the archive was not
  collecting; the flattened files cannot tell these apart. Check coverage before interpreting.
* **Fields depend on the agency.** For example, BCRTA's feed never fills `current_status` or
  `stop_id` in Vehicle Positions, so stop times are estimated from GPS alone.
