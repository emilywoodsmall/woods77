# Methodology

This document explains how actual stop times are estimated, precisely enough to reproduce or
critique the results. The design rationale is in [architecture.md](architecture.md).

## Inputs

* **GTFS static schedule**: trips, stop times, stops, calendars, route shapes. Scheduled times are
  interpreted exactly as the GTFS specification defines them: seconds after "noon minus 12 hours"
  on the service date in the agency's time zone. This keeps trips after midnight (e.g. `25:30:00`)
  on the correct service date and handles daylight-saving days correctly.
* **GTFS-Realtime Vehicle Positions**: for each vehicle, a position (latitude/longitude), the trip it
  is serving, a timestamp, and optionally speed and stop status.

## Step 1: Match realtime positions to scheduled trips

Positions are matched to trips by `trip_id`, and to a service date by the realtime `start_date`
(or, if absent, by which date's scheduled window the position falls in). Repeated copies of the
same position are removed, and positions more than 5 minutes old when fetched are discarded.

## Step 2: Place positions along the route

Each position is projected onto the trip's route path from `shapes.txt` and expressed as a distance
in metres from the start. When a route passes the same place twice (loops, out-and-back), the
position is assigned to the pass consistent with forward progress. Positions more than 50 m from the
route are treated as off-route and ignored; small backward jumps from GPS noise are clamped.
Stops are placed along the same path in the same way.

Because the realtime feed often switches a bus to its next trip just before it reaches the last
stop, positions from the same bus in the 10 minutes before and 15 minutes after a trip are used,
but only at the trip's first and last stops.

## Step 3: Estimate times at each stop

The best available evidence is used, in this fixed order:

| Order | Method code | What it gives | When it applies |
|---|---|---|---|
| 1 | `observed_stop_status` | Arrival and departure | The feed says the bus is STOPPED_AT this stop. Times are midpoints between the last position before and the first position with that status (and likewise for departure) |
| 2 | `gps_dwell` | Arrival and departure | At least 2 positions within 30 m of the stop at walking speed or slower. Arrival is when the bus entered the 30 m zone; departure is when it left it |
| 3 | `gps_passage` | Passing time only | The moment the bus passed the stop, interpolated linearly between the positions just before and after it |
| – | none | No time | None of the above; the stop is recorded as `no_evidence` (trip had data) or `no_data` (trip had none) |

Rules applied to every method:

* Interpolation is only allowed between positions **at most 120 seconds apart**. Longer gaps leave
  the stop unmeasured rather than risk a large error.
* Times must not go backwards along a trip; a time that does is removed and flagged `non_monotone`.
* Times more than 30 minutes early or 90 minutes late are removed and flagged `implausible_time`.
* Predicted times from the feed are never used as actual times.

**Leave time at a timepoint** = departure time if measured, otherwise the passing time. At the first
stop it is when the bus left the 30 m zone; at the last stop only arrival is defined.

## Uncertainty and knowable time

Each estimated time carries `*_uncertainty_s`, half the gap between the two positions it was
interpolated from (typically about 10 s with 20-second reporting). Rounding to the nearest minute in
reports adds up to 30 s. Each stop event also records `knowable_at`: when the later of the positions
used was first available. Forecasting work must only use stop events whose `knowable_at` is before
the moment of prediction.

## Definitions used in the outputs

* **Scheduled leave** = the GTFS departure time at the timepoint.
* **Actual leave** = the estimated leave time, on the same service-day clock.
* **Minutes late** = actual leave − scheduled leave (negative = left early).
* The `status` column in `details/` labels each departure early (more than `early_min`, default 1,
  minutes before), late (more than `late_min`, default 5, minutes after), or on time.

## Reproducibility

Outputs record the schedule's content fingerprint, the configuration fingerprint, and the algorithm
version. With the same inputs, configuration, and version, reruns produce byte-identical files
(this is checked by the automated tests).
