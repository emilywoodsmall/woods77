"""Time handling.

Rules (architecture doc, section 4):
* GTFS stop times are integer seconds since the *service-day anchor*, which the spec
  defines as "noon minus 12 hours" on the service date in the agency timezone. They may
  exceed 24:00:00 and are never parsed as clock times.
* Instants are Unix seconds (UTC). Nothing past the parsing boundary uses naive datetimes.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from typing import Optional
from zoneinfo import ZoneInfo


def parse_gtfs_time(value: Optional[str]) -> Optional[int]:
    """'25:30:00' -> 91800. Blank -> None. Raises ValueError on malformed input."""
    if value is None:
        return None
    value = value.strip()
    if not value:
        return None
    parts = value.split(":")
    if len(parts) != 3:
        raise ValueError(f"Bad GTFS time: {value!r}")
    h, m, s = (int(p) for p in parts)
    if not (0 <= m < 60 and 0 <= s < 60 and h >= 0):
        raise ValueError(f"Bad GTFS time: {value!r}")
    return h * 3600 + m * 60 + s


def format_gtfs_time(secs: Optional[int]) -> str:
    if secs is None:
        return ""
    return f"{secs // 3600:02d}:{secs % 3600 // 60:02d}:{secs % 60:02d}"


def parse_yyyymmdd(value: str) -> date:
    return datetime.strptime(value.strip(), "%Y%m%d").date()


def to_yyyymmdd(d: date) -> str:
    return d.strftime("%Y%m%d")


def service_day_anchor(service_date: date, tz: ZoneInfo) -> float:
    """Unix time of 'noon minus 12 hours' on service_date in tz.

    Equals local midnight on ordinary days; differs by an hour on DST transition days,
    exactly as the GTFS spec requires.
    """
    noon = datetime(service_date.year, service_date.month, service_date.day, 12, tzinfo=tz)
    return noon.timestamp() - 12 * 3600


def gtfs_to_unix(service_date: date, secs: Optional[int], tz: ZoneInfo) -> Optional[float]:
    if secs is None:
        return None
    return service_day_anchor(service_date, tz) + secs


def unix_to_utc(ts: Optional[float]) -> Optional[datetime]:
    if ts is None:
        return None
    return datetime.fromtimestamp(ts, tz=timezone.utc)


def unix_to_local_iso(ts: Optional[float], tz: ZoneInfo) -> str:
    if ts is None:
        return ""
    return datetime.fromtimestamp(ts, tz=tz).isoformat(timespec="seconds")


def adjacent_dates(d: date):
    return [d - timedelta(days=1), d, d + timedelta(days=1)]
