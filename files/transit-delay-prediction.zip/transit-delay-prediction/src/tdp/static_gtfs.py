"""Static GTFS: load, validate, and answer schedule questions for a service date.

Works for any standard feed. Files are read as text first and typed explicitly; unknown
columns and non-standard files are ignored here (they remain in the raw source).
"""
from __future__ import annotations

import hashlib
import io
import logging
import zipfile
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Dict, List, Optional
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

from .geo import Projector, RoutePath, build_path, place_monotone
from .timeutil import parse_gtfs_time, to_yyyymmdd

log = logging.getLogger(__name__)

REQUIRED = ["agency", "routes", "trips", "stop_times", "stops"]
OPTIONAL = ["calendar", "calendar_dates", "shapes", "feed_info", "frequencies"]
WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]


@dataclass
class TripSchedule:
    """One trip's ordered stops with scheduled seconds and position along its path."""

    trip_id: str
    route_id: str
    direction_id: str
    block_id: str
    shape_key: str
    stops: pd.DataFrame  # stop_sequence, stop_id, stop_name, arr_secs, dep_secs, is_timepoint,
                         # sched_interpolated, stop_dist_m

    @property
    def first_secs(self) -> int:
        return int(self.stops.dep_secs.iloc[0])

    @property
    def last_secs(self) -> int:
        return int(self.stops.arr_secs.iloc[-1])


@dataclass
class StaticFeed:
    tables: Dict[str, pd.DataFrame]
    source: str
    content_hash: str
    tz: ZoneInfo
    timepoint_rule: str
    stop_snap_m: float
    warnings: List[str] = field(default_factory=list)
    _paths: Dict[str, RoutePath] = field(default_factory=dict)
    _schedules: Dict[str, TripSchedule] = field(default_factory=dict)

    # ------------------------------------------------------------------ loading
    @classmethod
    def load(cls, path: str, tz_override: Optional[str] = None, timepoint_rule: str = "auto",
             stop_snap_m: float = 100.0) -> "StaticFeed":
        p = Path(path)
        raw: Dict[str, bytes] = {}
        if p.is_dir():
            for name in REQUIRED + OPTIONAL:
                f = p / f"{name}.txt"
                if f.exists():
                    raw[name] = f.read_bytes()
        elif zipfile.is_zipfile(p):
            with zipfile.ZipFile(p) as z:
                members = {Path(n).name: n for n in z.namelist()}
                for name in REQUIRED + OPTIONAL:
                    if f"{name}.txt" in members:
                        raw[name] = z.read(members[f"{name}.txt"])
        else:
            raise FileNotFoundError(f"GTFS path is neither a folder nor a zip: {path}")

        missing = [n for n in REQUIRED if n not in raw]
        if missing:
            raise ValueError(f"GTFS feed is missing required file(s): {missing}")
        if "calendar" not in raw and "calendar_dates" not in raw:
            raise ValueError("GTFS feed needs calendar.txt and/or calendar_dates.txt")

        h = hashlib.sha256()
        for name in sorted(raw):
            h.update(name.encode())
            h.update(raw[name])
        tables = {
            name: pd.read_csv(io.BytesIO(data), dtype=str, keep_default_na=False, encoding="utf-8-sig")
            .rename(columns=lambda c: c.strip())
            for name, data in raw.items()
        }
        for df in tables.values():
            for c in df.columns:
                df[c] = df[c].str.strip()

        tz_name = tz_override or tables["agency"]["agency_timezone"].iloc[0]
        feed = cls(tables=tables, source=str(p), content_hash=h.hexdigest()[:16], tz=ZoneInfo(tz_name),
                   timepoint_rule=timepoint_rule, stop_snap_m=stop_snap_m)
        feed._validate()
        return feed

    def _validate(self) -> None:
        t = self.tables
        if t["trips"].trip_id.duplicated().any():
            raise ValueError("trips.txt has duplicate trip_id values")
        if t["stops"].stop_id.duplicated().any():
            raise ValueError("stops.txt has duplicate stop_id values")
        st = t["stop_times"]
        if st.duplicated(["trip_id", "stop_sequence"]).any():
            raise ValueError("stop_times.txt has duplicate (trip_id, stop_sequence)")
        orphan = set(st.trip_id) - set(t["trips"].trip_id)
        if orphan:
            self.warnings.append(f"{len(orphan)} trip_id(s) in stop_times.txt are not in trips.txt")
        bad_stops = set(st.stop_id) - set(t["stops"].stop_id)
        if bad_stops:
            raise ValueError(f"stop_times.txt references unknown stop_id(s): {sorted(bad_stops)[:5]}")
        if "frequencies" in t and len(t["frequencies"]):
            self.warnings.append("frequencies.txt found: headway-based trips are not supported yet and "
                                 "will be treated as single runs at their stop_times.txt times")
        if "shapes" not in t:
            self.warnings.append("No shapes.txt: route paths will be approximated from stop locations")
        if self.timepoint_rule == "column" and "timepoint" not in st.columns:
            raise ValueError("timepoint_rule=column but stop_times.txt has no timepoint column")
        for w in self.warnings:
            log.warning("static_gtfs_warning %s", w)

    # ------------------------------------------------------------------ calendar
    def active_service_ids(self, d: date) -> set:
        ymd = to_yyyymmdd(d)
        active = set()
        cal = self.tables.get("calendar")
        if cal is not None and len(cal):
            dow = WEEKDAYS[d.weekday()]
            m = (cal[dow] == "1") & (cal.start_date <= ymd) & (cal.end_date >= ymd)
            active |= set(cal.loc[m, "service_id"])
        cd = self.tables.get("calendar_dates")
        if cd is not None and len(cd):
            for _, r in cd[cd.date == ymd].iterrows():
                if r.exception_type == "1":
                    active.add(r.service_id)
                elif r.exception_type == "2":
                    active.discard(r.service_id)
        return active

    def trips_on(self, d: date) -> pd.DataFrame:
        trips = self.tables["trips"]
        return trips[trips.service_id.isin(self.active_service_ids(d))]

    # ------------------------------------------------------------------ geometry
    @property
    def projector(self) -> Projector:
        if not hasattr(self, "_proj"):
            lat = pd.to_numeric(self.tables["stops"].stop_lat, errors="coerce").dropna()
            self._proj = Projector(float(lat.mean()))
        return self._proj

    def _stop_xy(self, stop_ids) -> tuple:
        s = self.tables["stops"].set_index("stop_id").loc[list(stop_ids)]
        return self.projector.xy(pd.to_numeric(s.stop_lat), pd.to_numeric(s.stop_lon))

    def path_for(self, trip_row) -> tuple:
        shape_id = trip_row.get("shape_id", "") if hasattr(trip_row, "get") else ""
        shapes = self.tables.get("shapes")
        if shape_id and shapes is not None:
            if shape_id not in self._paths:
                g = shapes[shapes.shape_id == shape_id].copy()
                if len(g):
                    g["_seq"] = g.shape_pt_sequence.astype(int)
                    g = g.sort_values("_seq")
                    self._paths[shape_id] = build_path(self.projector, pd.to_numeric(g.shape_pt_lat),
                                                       pd.to_numeric(g.shape_pt_lon))
            if shape_id in self._paths:
                return shape_id, self._paths[shape_id]
        key = f"__stops__{trip_row['trip_id']}"
        if key not in self._paths:
            st = self._stop_times_for(trip_row["trip_id"])
            s = self.tables["stops"].set_index("stop_id").loc[list(st.stop_id)]
            self._paths[key] = build_path(self.projector, pd.to_numeric(s.stop_lat),
                                          pd.to_numeric(s.stop_lon), synthetic=True)
        return key, self._paths[key]

    # ------------------------------------------------------------------ schedules
    def _stop_times_for(self, trip_id: str) -> pd.DataFrame:
        if not hasattr(self, "_st_groups"):
            st = self.tables["stop_times"].copy()
            st["_seq"] = st.stop_sequence.astype(int)
            self._st_groups = {k: g.sort_values("_seq") for k, g in st.groupby("trip_id", sort=False)}
        return self._st_groups[trip_id]

    def schedule(self, trip_row) -> Optional[TripSchedule]:
        trip_id = trip_row["trip_id"]
        if trip_id in self._schedules:
            return self._schedules[trip_id]
        try:
            st = self._stop_times_for(trip_id)
        except KeyError:
            return None
        names = self.tables["stops"].set_index("stop_id").stop_name
        arr = [parse_gtfs_time(v) for v in st.arrival_time]
        dep = [parse_gtfs_time(v) for v in st.departure_time]
        arr = [a if a is not None else d for a, d in zip(arr, dep)]
        dep = [d if d is not None else a for a, d in zip(arr, dep)]

        key, path = self.path_for(trip_row)
        xs, ys = self._stop_xy(st.stop_id)
        dist = place_monotone(path, xs, ys, self.stop_snap_m)
        if np.isnan(dist).any() and "shape_dist_traveled" in st.columns:
            # Fall back to the feed's own distances, rescaled to metres along our path.
            sdt = pd.to_numeric(st.shape_dist_traveled, errors="coerce").to_numpy()
            if np.nanmax(sdt) > 0:
                dist = np.where(np.isnan(dist), sdt / np.nanmax(sdt) * path.length, dist)

        has_time = np.array([a is not None for a in arr])
        interp = ~has_time
        if interp.any():
            if has_time.sum() < 2 or np.isnan(dist).any():
                return None
            known = np.flatnonzero(has_time)
            filled = np.interp(dist, dist[known], np.array([arr[i] for i in known], float))
            arr = [a if a is not None else int(round(f)) for a, f in zip(arr, filled)]
            dep = [d if d is not None else int(round(f)) for d, f in zip(dep, filled)]

        if self.timepoint_rule == "all":
            tp = np.ones(len(st), bool)
        elif "timepoint" in st.columns and (st.timepoint == "1").any():
            tp = (st.timepoint == "1").to_numpy()
        elif self.timepoint_rule == "column":
            tp = np.zeros(len(st), bool)
        else:  # auto without a usable column: stops with explicit times are timepoints
            tp = has_time.copy()

        stops = pd.DataFrame({
            "stop_sequence": st._seq.to_numpy(),
            "stop_id": st.stop_id.to_numpy(),
            "stop_name": [names.get(s, s) for s in st.stop_id],
            "arr_secs": arr,
            "dep_secs": dep,
            "is_timepoint": tp,
            "sched_interpolated": interp,
            "stop_dist_m": dist,
        })
        sched = TripSchedule(
            trip_id=trip_id,
            route_id=trip_row.get("route_id", ""),
            direction_id=trip_row.get("direction_id", "") or "",
            block_id=trip_row.get("block_id", "") or "",
            shape_key=key,
            stops=stops,
        )
        self._schedules[trip_id] = sched
        return sched

    def route_info(self) -> pd.DataFrame:
        r = self.tables["routes"].copy()
        for c in ["route_short_name", "route_long_name", "route_color"]:
            if c not in r.columns:
                r[c] = ""
        return r.set_index("route_id")
