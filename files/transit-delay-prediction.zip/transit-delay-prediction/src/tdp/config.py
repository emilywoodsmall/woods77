"""Pipeline configuration.

Everything agency-specific lives in a YAML file (see config/feeds/). The core code
never branches on feed_id; it only reads these settings.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml


@dataclass
class Thresholds:
    """Reconstruction parameters. Defaults are documented in the architecture doc (section 10)."""

    stop_radius_m: float = 30.0            # a bus within this distance (along the route) is "at" the stop
    max_interp_gap_s: float = 120.0        # never interpolate between GPS fixes further apart than this
    stationary_speed_mps: float = 0.5      # at or below this speed a fix counts as standing still
    min_dwell_fixes: int = 2               # stationary fixes needed to measure arrival and departure separately
    max_cross_track_m: float = 50.0        # fixes further than this from the route path are off-route
    jitter_m: float = 25.0                 # backward GPS movement tolerated before a fix is discarded
    max_speed_mps: float = 35.0            # implied speeds above this are physically implausible
    stop_snap_m: float = 100.0             # max distance from a stop to the route path when placing stops
    terminal_borrow_before_s: float = 600  # use same-bus fixes this long before a trip (first-stop departure)
    terminal_borrow_after_s: float = 900   # use same-bus fixes this long after a trip (last-stop arrival)
    max_fix_age_s: float = 300.0           # fixes older than this when fetched are stale
    service_date_tolerance_s: float = 1800 # how far outside a trip's scheduled window a fix may be
    plausible_min_delay_s: float = -1800   # estimated times outside this band are rejected as mismatches
    plausible_max_delay_s: float = 5400


@dataclass
class OnTime:
    """On-time definition used in reports (minutes relative to schedule)."""

    early_min: float = 1.0   # leaving more than this many minutes before schedule counts as early
    late_min: float = 5.0    # more than this many minutes after schedule counts as late


@dataclass
class TripRule:
    """Recover a trip_id from entity_id when the trip descriptor is blank (a common vendor quirk)."""

    name: str
    entity_id_regex: str                   # must contain a named group (?P<trip_id>...)
    stream: str = "primary"


@dataclass
class RtColumns:
    """Column mapping for the generic 'table' realtime format (CSV or Parquet)."""

    vehicle_id: str = "vehicle_id"
    trip_id: str = "trip_id"
    lat: str = "latitude"
    lon: str = "longitude"
    ts: str = "timestamp"
    start_date: Optional[str] = "start_date"
    speed: Optional[str] = "speed"
    entity_id: Optional[str] = "entity_id"
    available_at: Optional[str] = None
    current_status: Optional[str] = None
    stop_id: Optional[str] = None
    current_stop_sequence: Optional[str] = None


@dataclass
class Archive:
    """Where to download historical realtime data from (used by `python -m tdp.history`)."""

    provider: str = "gtfsrt_io"                        # currently the only supported archive
    vehicle_positions_url: Optional[str] = None        # the agency's live Vehicle Positions URL
    base_url: str = "http://parquet.gtfsrt.io"         # archive host for flattened daily Parquet


@dataclass
class FeedConfig:
    feed_id: str = "feed"
    timezone: Optional[str] = None         # override agency.txt timezone (rarely needed)
    timepoint_rule: str = "auto"           # auto | column | all
    rt_format: str = "auto"                # auto | pb | flat_parquet | table
    rt_columns: RtColumns = field(default_factory=RtColumns)
    trip_rules: List[TripRule] = field(default_factory=list)
    thresholds: Thresholds = field(default_factory=Thresholds)
    on_time: OnTime = field(default_factory=OnTime)
    archive: Archive = field(default_factory=Archive)

    def config_hash(self) -> str:
        blob = json.dumps(asdict(self), sort_keys=True, default=str).encode()
        return hashlib.sha256(blob).hexdigest()[:12]


def _build(cls, data: Optional[Dict[str, Any]]):
    data = data or {}
    known = {f.name for f in fields(cls)}
    unknown = set(data) - known
    if unknown:
        raise ValueError(f"Unknown {cls.__name__} setting(s): {sorted(unknown)}")
    return cls(**data)


def load_config(path: Optional[str]) -> FeedConfig:
    if not path:
        return FeedConfig()
    raw = yaml.safe_load(Path(path).read_text()) or {}
    cfg = FeedConfig(
        feed_id=raw.get("feed_id", "feed"),
        timezone=raw.get("timezone"),
        timepoint_rule=raw.get("timepoint_rule", "auto"),
        rt_format=raw.get("rt_format", "auto"),
        rt_columns=_build(RtColumns, raw.get("rt_columns")),
        trip_rules=[_build(TripRule, r) for r in raw.get("trip_rules", [])],
        thresholds=_build(Thresholds, raw.get("thresholds")),
        on_time=_build(OnTime, raw.get("on_time")),
        archive=_build(Archive, raw.get("archive")),
    )
    extra = set(raw) - {"feed_id", "timezone", "timepoint_rule", "rt_format", "rt_columns",
                        "trip_rules", "thresholds", "on_time", "archive"}
    if extra:
        raise ValueError(f"Unknown top-level config key(s): {sorted(extra)}")
    if cfg.timepoint_rule not in {"auto", "column", "all"}:
        raise ValueError("timepoint_rule must be auto, column or all")
    return cfg
