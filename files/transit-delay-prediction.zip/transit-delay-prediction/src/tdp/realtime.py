"""GTFS-Realtime Vehicle Positions -> one normalized table of vehicle fixes.

Supported inputs (all produce the same columns):
* pb           raw GTFS-RT protobuf files (the preferred, most reproducible source)
* flat_parquet archive files already flattened one row per entity (e.g. gtfsrt.io)
* table        any CSV/Parquet with a column mapping in the config

Normalized columns:
    vehicle_id, trip_id, start_date, entity_id, stream, lat, lon, speed, ts, available_at,
    current_status, stop_id, current_stop_sequence, source_file
`ts` is the vehicle's own timestamp; `available_at` is when the observation was first
fetchable (fetch time if known, else feed header time). Presence matters: missing values
are NaN/empty, never silently zero.
"""
from __future__ import annotations

import glob
import logging
import os
import re
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple

import duckdb
import numpy as np
import pandas as pd

from .config import FeedConfig

log = logging.getLogger(__name__)

COLUMNS = ["vehicle_id", "trip_id", "start_date", "entity_id", "stream", "lat", "lon", "speed", "ts",
           "available_at", "current_status", "stop_id", "current_stop_sequence", "source_file"]
STOPPED_AT = 1  # VehicleStopStatus enum value in the GTFS-RT spec
Window = Optional[Tuple[float, float]]  # (start, end) in Unix seconds

_ISO_IN_NAME = re.compile(r"(\d{4}-\d{2}-\d{2}T\d{2}[:_-]?\d{2}[:_-]?\d{2}(?:\.\d+)?)Z?")


def expand_paths(paths: List[str], suffixes: Tuple[str, ...]) -> List[str]:
    out: List[str] = []
    for p in paths:
        if os.path.isdir(p):
            for root, _, files in os.walk(p):
                out += [os.path.join(root, f) for f in files if f.lower().endswith(suffixes)]
        else:
            matches = glob.glob(p, recursive=True)
            out += matches if matches else [p]
    return sorted(set(out))


def detect_format(paths: List[str]) -> str:
    files = [f for f in expand_paths(paths, (".pb", ".parquet", ".csv")) if os.path.isfile(f)]
    if not files:
        raise FileNotFoundError(f"No realtime files found at: {', '.join(paths)}. Check the path "
                                f"(use `find ~/Downloads -name '*.parquet'` to locate files).")
    if all(f.lower().endswith(".pb") for f in files):
        return "pb"
    if files[0].lower().endswith(".parquet"):
        cols = [r[0] for r in duckdb.sql(f"describe select * from read_parquet('{files[0]}')").fetchall()]
        if {"latitude", "longitude", "fetch_timestamp"} <= set(cols):
            return "flat_parquet"
    return "table"


# --------------------------------------------------------------------------- pb
def _fetch_time_from_name(path: str):
    m = _ISO_IN_NAME.search(os.path.basename(path))
    if not m:
        return None
    s = re.sub(r"T(\d{2})[_-]?(\d{2})[_-]?(\d{2})", r"T\1:\2:\3", m.group(1))
    try:
        return datetime.fromisoformat(s).replace(tzinfo=timezone.utc).timestamp()
    except ValueError:
        return None


def _decode(path: str):
    from google.transit import gtfs_realtime_pb2
    msg = gtfs_realtime_pb2.FeedMessage()
    with open(path, "rb") as fh:
        msg.ParseFromString(fh.read())
    return msg


def pb_file_time(path: str) -> Optional[float]:
    """When a snapshot was fetched: from its file name if it contains a timestamp, else its header."""
    t = _fetch_time_from_name(path)
    if t is not None:
        return t
    try:
        msg = _decode(path)
    except Exception:  # noqa: BLE001
        return None
    return float(msg.header.timestamp) if msg.header.HasField("timestamp") else None


def load_pb(files: List[str], window: Window = None) -> pd.DataFrame:
    try:
        from google.transit import gtfs_realtime_pb2  # noqa: F401
    except ImportError as e:  # pragma: no cover
        raise ImportError("Reading .pb files needs: pip install gtfs-realtime-bindings") from e
    rows = []
    bad = 0
    for path in files:
        try:
            msg = _decode(path)
        except Exception:  # noqa: BLE001 - a corrupt snapshot must not stop the run
            bad += 1
            continue
        hdr = float(msg.header.timestamp) if msg.header.HasField("timestamp") else None
        avail = _fetch_time_from_name(path) or hdr or os.path.getmtime(path)
        for e in msg.entity:
            if not e.HasField("vehicle"):
                continue
            v = e.vehicle
            if not v.HasField("position"):
                continue
            ts = float(v.timestamp) if v.HasField("timestamp") else np.nan
            t = ts if ts == ts else avail
            if window is not None and not (window[0] <= t <= window[1]):
                continue
            tr = v.trip if v.HasField("trip") else None
            vd = v.vehicle if v.HasField("vehicle") else None
            vid = (vd.id if vd is not None and vd.HasField("id") else "") or \
                  (vd.label if vd is not None and vd.HasField("label") else "") or e.id
            rows.append({
                "vehicle_id": vid,
                "trip_id": tr.trip_id if tr is not None and tr.HasField("trip_id") else "",
                "start_date": tr.start_date if tr is not None and tr.HasField("start_date") else "",
                "entity_id": e.id,
                "lat": v.position.latitude,
                "lon": v.position.longitude,
                "speed": v.position.speed if v.position.HasField("speed") else np.nan,
                "ts": ts,
                "available_at": avail,
                "current_status": v.current_status if v.HasField("current_status") else np.nan,
                "stop_id": v.stop_id if v.HasField("stop_id") else "",
                "current_stop_sequence": v.current_stop_sequence if v.HasField("current_stop_sequence") else np.nan,
                "source_file": path,
            })
    if bad:
        log.warning("pb_decode_failures count=%d", bad)
    log.info("pb_loaded files=%d fixes=%d", len(files), len(rows))
    return pd.DataFrame(rows, columns=[c for c in COLUMNS if c != "stream"])


# --------------------------------------------------------------------------- parquet / table
def _sql_list(files: List[str]) -> str:
    return "[" + ",".join("'" + f.replace("'", "''") + "'" for f in files) + "]"


def load_flat_parquet(files: List[str], window: Window = None) -> pd.DataFrame:
    cols = {r[0] for r in duckdb.sql(f"describe select * from read_parquet({_sql_list(files)}, union_by_name=true)").fetchall()}

    def pick(name: str, expr: str, default: str) -> str:
        return expr if name in cols else default

    time_filter = ""
    if window is not None:
        t = pick("timestamp", "coalesce(timestamp::double, epoch(fetch_timestamp))", "epoch(fetch_timestamp)")
        time_filter = f"and {t} between {window[0]} and {window[1]}"
    q = f"""
    select
      coalesce(nullif({pick('vehicle_id', 'vehicle_id', "''")}, ''), nullif({pick('vehicle_label', 'vehicle_label', "''")}, ''), entity_id) as vehicle_id,
      coalesce({pick('trip_id', 'trip_id', "''")}, '') as trip_id,
      coalesce({pick('start_date', 'start_date', "''")}, '') as start_date,
      entity_id,
      latitude::double as lat, longitude::double as lon,
      {pick('speed', 'speed::double', 'null::double')} as speed,
      {pick('timestamp', 'timestamp::double', 'null::double')} as ts,
      epoch(fetch_timestamp) as available_at,
      {pick('current_status', 'current_status::double', 'null::double')} as current_status,
      coalesce({pick('stop_id', 'stop_id', "''")}, '') as stop_id,
      {pick('current_stop_sequence', 'current_stop_sequence::double', 'null::double')} as current_stop_sequence,
      {pick('source_file', 'source_file', "''")} as source_file
    from read_parquet({_sql_list(files)}, union_by_name=true)
    where latitude is not null and longitude is not null {time_filter}
    """
    df = duckdb.sql(q).df()
    log.info("flat_parquet_loaded files=%d fixes=%d", len(files), len(df))
    return df


def load_table(files: List[str], cfg: FeedConfig, window: Window = None) -> pd.DataFrame:
    m = cfg.rt_columns
    frames = []
    for f in files:
        reader = f"read_parquet('{f}')" if f.lower().endswith(".parquet") else f"read_csv('{f}', all_varchar=true)"
        where = ""
        if window is not None:
            where = f'where try_cast("{m.ts}" as double) between {window[0]} and {window[1]}'
        src = duckdb.sql(f"select * from {reader} {where}").df()
        out = pd.DataFrame({
            "vehicle_id": src[m.vehicle_id].astype(str),
            "trip_id": src[m.trip_id].fillna("").astype(str),
            "lat": pd.to_numeric(src[m.lat]),
            "lon": pd.to_numeric(src[m.lon]),
            "ts": pd.to_numeric(src[m.ts]),
        })
        def opt(col, conv, default):
            return conv(src[col]) if col and col in src.columns else default
        out["start_date"] = opt(m.start_date, lambda s: s.fillna("").astype(str), "")
        out["entity_id"] = opt(m.entity_id, lambda s: s.fillna("").astype(str), "")
        out["speed"] = opt(m.speed, lambda s: pd.to_numeric(s, errors="coerce"), np.nan)
        out["available_at"] = opt(m.available_at, lambda s: pd.to_numeric(s, errors="coerce"), np.nan)
        out["current_status"] = opt(m.current_status, lambda s: pd.to_numeric(s, errors="coerce"), np.nan)
        out["stop_id"] = opt(m.stop_id, lambda s: s.fillna("").astype(str), "")
        out["current_stop_sequence"] = opt(m.current_stop_sequence, lambda s: pd.to_numeric(s, errors="coerce"), np.nan)
        out["source_file"] = f
        frames.append(out)
    df = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=COLUMNS)
    log.info("table_loaded files=%d fixes=%d", len(files), len(df))
    return df


# --------------------------------------------------------------------------- normalize
def normalize(df: pd.DataFrame, cfg: FeedConfig) -> Tuple[pd.DataFrame, Dict[str, int]]:
    """Resolve trips via config rules, drop stale fixes, and deduplicate repeated fixes."""
    stats: Dict[str, int] = {"fixes_loaded": int(len(df))}
    df = df.copy()
    for c in COLUMNS:
        if c not in df.columns:
            df[c] = pd.Series(dtype=float if c in ("lat", "lon", "speed", "ts", "available_at",
                                                    "current_status", "current_stop_sequence") else object)
    for c in ["vehicle_id", "trip_id", "start_date", "entity_id", "stop_id", "source_file"]:
        df[c] = df[c].fillna("").astype(str).str.strip()
    df["stream"] = "primary"

    # Vendor quirk handling from config: recover trip_id from entity_id when blank.
    for rule in cfg.trip_rules:
        rx = re.compile(rule.entity_id_regex)
        blank = df.trip_id == ""
        found = df.loc[blank, "entity_id"].str.extract(rx)
        if "trip_id" in found.columns:
            hit = found.trip_id.notna()
            idx = found.index[hit]
            df.loc[idx, "trip_id"] = found.loc[hit, "trip_id"]
            df.loc[idx, "stream"] = rule.stream
            stats[f"trip_rule_{rule.name}"] = int(hit.sum())

    df["available_at"] = df["available_at"].astype(float)
    df["ts"] = df["ts"].astype(float)
    df["ts"] = df["ts"].fillna(df["available_at"])            # no vehicle timestamp: use fetch time
    df["available_at"] = df["available_at"].fillna(df["ts"])  # no fetch time: best available proxy

    age = df.available_at - df.ts
    stale = age > cfg.thresholds.max_fix_age_s
    future = age < -60  # vehicle clock ahead of fetch clock by over a minute
    stats["fixes_stale_dropped"] = int(stale.sum())
    stats["fixes_future_dropped"] = int(future.sum())
    df = df[~stale & ~future]

    unassigned = df.trip_id == ""
    stats["fixes_without_trip"] = int(unassigned.sum())

    before = len(df)
    df = (df.sort_values(["vehicle_id", "ts", "available_at", "source_file"], kind="mergesort")
            .drop_duplicates(["vehicle_id", "ts"], keep="first"))
    stats["fixes_duplicate_dropped"] = int(before - len(df))
    stats["fixes_kept"] = int(len(df))
    return df.reset_index(drop=True), stats


class RealtimeSource:
    """A set of realtime files the user supplied (or downloaded), read one time window at a time.

    Only the records needed for the requested window are kept in memory, so months of snapshots
    can be processed on a laptop. For .pb files, each file's fetch time is taken from its name when
    it contains one (e.g. 2026-09-16T08-00-20Z.pb), otherwise from the feed header; files outside
    the window are not decoded at all.
    """

    PB_MARGIN_S = 600  # fetch time can trail vehicle time; read files slightly beyond the window

    def __init__(self, paths: List[str], cfg: FeedConfig):
        self.paths = paths
        self.cfg = cfg
        self.format = cfg.rt_format if cfg.rt_format != "auto" else detect_format(paths)
        suffixes = {"pb": (".pb",), "flat_parquet": (".parquet",), "table": (".csv", ".parquet")}.get(self.format)
        if suffixes is None:
            raise ValueError(f"Unknown realtime format {self.format!r}")
        self.files = [f for f in expand_paths(paths, suffixes) if os.path.isfile(f)]
        if not self.files:
            raise FileNotFoundError(f"No {self.format} realtime files found at: {', '.join(paths)}")
        self._pb_times: Optional[List[Tuple[Optional[float], str]]] = None

    def _pb_files_for(self, window: Window) -> List[str]:
        if window is None:
            return self.files
        if self._pb_times is None:  # built once per run; headers only, entities are not kept
            self._pb_times = [(pb_file_time(f), f) for f in self.files]
        lo, hi = window[0] - self.PB_MARGIN_S, window[1] + self.PB_MARGIN_S
        return [f for t, f in self._pb_times if t is None or lo <= t <= hi]

    def load(self, window: Window = None) -> Tuple[pd.DataFrame, Dict[str, int]]:
        if self.format == "pb":
            files = self._pb_files_for(window)
            raw = load_pb(files, window)
        elif self.format == "flat_parquet":
            files = self.files
            raw = load_flat_parquet(files, window)
        else:
            files = self.files
            raw = load_table(files, self.cfg, window)
        df, stats = normalize(raw, self.cfg)
        stats["files_read"] = len(files)
        return df, stats


def load_vehicle_fixes(paths: List[str], cfg: FeedConfig, window: Window = None) -> Tuple[pd.DataFrame, Dict[str, int], str]:
    src = RealtimeSource(paths, cfg)
    df, stats = src.load(window)
    return df, stats, src.format
