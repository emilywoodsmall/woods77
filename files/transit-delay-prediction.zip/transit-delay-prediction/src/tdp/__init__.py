"""Transit Schedule Adherence Analyzer: scheduled vs. actual leave times from GTFS + GTFS-Realtime."""
__version__ = "1.0.0"
