"""Write results. Output is deterministic: same inputs + config + code -> identical files.

Per service date, in <out>/<feed_id>/<service_date>/:
  stop_events.csv / .parquet     every scheduled stop visit, with method + uncertainty per time
  trips.csv                      one row per scheduled trip
  timepoint_departures.csv       required (scheduled) vs actual leave times at timepoints
  qc_summary.json                data-quality metrics for the day
  report.html                    interactive charts (built by report.py)
Files are written to a temporary name and renamed, so a crash never leaves half a file.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Dict
from zoneinfo import ZoneInfo

import duckdb
import pandas as pd

from .config import FeedConfig
from .reconstruct import DayResult
from .timeutil import format_gtfs_time, unix_to_local_iso


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _local(series: pd.Series, tz: ZoneInfo) -> pd.Series:
    return series.map(lambda v: unix_to_local_iso(None if pd.isna(v) else float(v), tz))


def leave_time_status(dev_s: float, cfg: FeedConfig) -> str:
    if dev_s < -cfg.on_time.early_min * 60:
        return "early"
    if dev_s > cfg.on_time.late_min * 60:
        return "late"
    return "on_time"


def timepoint_departures(events: pd.DataFrame, tz: ZoneInfo, cfg: FeedConfig) -> pd.DataFrame:
    """Scheduled ('required') vs actual leave time at every timepoint that has a departure."""
    if not len(events):
        return pd.DataFrame()
    tp = events[events.is_timepoint & ~events.is_last_stop].copy()
    tp["actual_leave_unix"] = tp.departure_unix.where(tp.departure_unix.notna(), tp.passage_unix)
    tp["leave_method"] = tp.departure_method.where(tp.departure_unix.notna(), tp.passage_method)
    tp["deviation_s"] = (tp.actual_leave_unix - tp.scheduled_departure_unix).round()
    tp["status"] = [None if pd.isna(v) else leave_time_status(v, cfg) for v in tp.deviation_s]
    out = pd.DataFrame({
        "service_date": tp.service_date,
        "route_id": tp.route_id,
        "route_short_name": tp.route_short_name,
        "direction_id": tp.direction_id,
        "block_id": tp.block_id,
        "trip_id": tp.trip_id,
        "vehicle_id": tp.vehicle_id,
        "stop_sequence": tp.stop_sequence,
        "stop_id": tp.stop_id,
        "stop_name": tp.stop_name,
        "is_first_stop": tp.is_first_stop,
        "required_leave_secs": tp.scheduled_departure_secs,  # GTFS service-day seconds (may exceed 86400)
        "required_leave_local": _local(tp.scheduled_departure_unix, tz),
        "actual_leave_local": _local(tp.actual_leave_unix, tz),
        "deviation_s": tp.deviation_s,
        "deviation_min": (tp.deviation_s / 60).round(1),
        "status": tp.status,
        "method": tp.leave_method,
        "uncertainty_s": tp.departure_uncertainty_s.where(tp.departure_unix.notna(), tp.passage_uncertainty_s),
        "knowable_at_unix": tp.knowable_at_unix,  # when this actual time first became known (leakage control)
        "weekday": pd.to_datetime(tp.service_date).dt.day_name(),
    })
    return out.reset_index(drop=True)


def write_day(result: DayResult, out_dir: Path, tz: ZoneInfo, cfg: FeedConfig) -> Dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    ev = result.events.copy()
    if len(ev):
        for col in ["scheduled_arrival", "scheduled_departure", "arrival", "departure", "passage", "knowable_at"]:
            ev[f"{col}_local"] = _local(ev[f"{col}_unix"], tz)
    paths = {
        "stop_events_csv": out_dir / "stop_events.csv",
        "stop_events_parquet": out_dir / "stop_events.parquet",
        "trips_csv": out_dir / "trips.csv",
        "timepoints_csv": out_dir / "timepoint_departures.csv",
        "qc": out_dir / "qc_summary.json",
    }
    _atomic_write_text(paths["stop_events_csv"], ev.to_csv(index=False, float_format="%.3f"))
    _atomic_write_text(paths["trips_csv"], result.trips.to_csv(index=False))
    tp = timepoint_departures(result.events, tz, cfg)
    _atomic_write_text(out_dir / "leave_times.csv", simple_leave_times(tp).to_csv(index=False, float_format="%.1f"))
    _atomic_write_text(paths["timepoints_csv"], tp.to_csv(index=False, float_format="%.1f"))
    if len(tp):
        write_timepoints_parquet(tp, out_dir / "timepoint_departures.parquet")
    _atomic_write_text(paths["qc"], json.dumps(result.qc, indent=2, sort_keys=True, default=str))
    tmp = paths["stop_events_parquet"].with_name("stop_events.parquet.tmp")
    con = duckdb.connect()
    con.register("ev", ev)
    con.execute(f"copy (select * from ev) to '{tmp.as_posix()}' (format parquet)")
    con.close()
    os.replace(tmp, paths["stop_events_parquet"])
    return paths


# Typed Parquet schema for analysis/ML: real dates and timestamps, IDs as text.
_TP_SQL = """
select service_date::DATE as service_date, weekday, route_id::VARCHAR as route_id, route_short_name,
       direction_id::VARCHAR as direction_id, block_id::VARCHAR as block_id, trip_id::VARCHAR as trip_id,
       vehicle_id::VARCHAR as vehicle_id, stop_sequence::INTEGER as stop_sequence, stop_id::VARCHAR as stop_id,
       stop_name, is_first_stop::BOOLEAN as is_first_stop, required_leave_secs::INTEGER as required_leave_secs,
       nullif(required_leave_local::VARCHAR, '')::TIMESTAMPTZ as required_leave,
       nullif(actual_leave_local::VARCHAR, '')::TIMESTAMPTZ as actual_leave,
       deviation_s::DOUBLE as deviation_s, deviation_min::DOUBLE as deviation_min, status, method,
       uncertainty_s::DOUBLE as uncertainty_s, to_timestamp(knowable_at_unix::DOUBLE) as knowable_at
from tp
"""


def write_timepoints_parquet(tp: pd.DataFrame, path: Path) -> None:
    tmp = path.with_name(path.name + ".tmp")
    con = duckdb.connect()
    con.execute("set TimeZone = 'UTC'")
    con.register("tp", tp)
    con.execute(f"copy ({_TP_SQL}) to '{tmp.as_posix()}' (format parquet)")
    con.close()
    os.replace(tmp, path)


# ---------------------------------------------------------------------------------------------
# The simple comparison tables. Scheduled and actual leave times use the same clock: time of the
# service day as HH:MM:SS, which (like GTFS) can exceed 24:00:00 after midnight, so the two
# columns can be compared directly.
SIMPLE_COLUMNS = ["service_date", "weekday", "route", "trip_id", "stop_sequence", "stop_id", "stop_name",
                  "scheduled_leave", "actual_leave", "minutes_late"]


def simple_leave_times(tp: pd.DataFrame) -> pd.DataFrame:
    """One row per run (trip) per timepoint per day: scheduled vs actual leave time."""
    if not len(tp):
        return pd.DataFrame(columns=SIMPLE_COLUMNS)
    actual = tp.required_leave_secs + tp.deviation_s
    out = pd.DataFrame({
        "service_date": tp.service_date,
        "weekday": pd.to_datetime(tp.service_date).dt.day_name(),
        "route": tp.route_short_name.astype(str).str.strip(),
        "trip_id": tp.trip_id,
        "stop_sequence": tp.stop_sequence.astype(int),
        "stop_id": tp.stop_id,
        "stop_name": tp.stop_name,
        "scheduled_leave": [format_gtfs_time(int(v)) for v in tp.required_leave_secs],
        "actual_leave": ["" if pd.isna(v) else format_gtfs_time(int(round(v))) for v in actual],
        "minutes_late": (tp.deviation_s / 60).round(1),
    })
    return out.sort_values(["route", "trip_id", "stop_sequence", "service_date"], kind="mergesort").reset_index(drop=True)


def leave_times_by_run(simple: pd.DataFrame) -> pd.DataFrame:
    """Wide table: one row per run and timepoint, one column per date holding minutes late."""
    keys = ["route", "trip_id", "stop_sequence", "stop_id", "stop_name", "scheduled_leave"]
    if not len(simple):
        return pd.DataFrame(columns=keys)
    wide = (simple.groupby(keys + ["service_date"], sort=False, dropna=False).minutes_late.first()
                  .unstack("service_date"))
    wide = wide.reindex(columns=sorted(simple.service_date.unique())).reset_index()
    wide.columns.name = None
    return wide.sort_values(["route", "scheduled_leave", "trip_id", "stop_sequence"], kind="mergesort").reset_index(drop=True)
