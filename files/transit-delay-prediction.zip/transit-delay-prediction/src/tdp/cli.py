"""Command line entry point.

Example:
    python -m tdp --gtfs data/gtfs.zip --rt data/vehicle_positions/ \
        --date 2026-09-16 --config config/feeds/bcrta.yaml --out output/
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from datetime import date
from pathlib import Path
from typing import List, Optional

from .config import load_config
from .outputs import timepoint_departures, write_day
from .realtime import load_vehicle_fixes
from .reconstruct import ALGORITHM_VERSION, reconstruct_day, service_window
from .report import build_report
from .static_gtfs import StaticFeed


def parse_args(argv: Optional[List[str]]) -> argparse.Namespace:
    p = argparse.ArgumentParser(prog="tdp", description="Reconstruct actual stop times from GTFS + GTFS-Realtime vehicle positions.")
    p.add_argument("--gtfs", required=True, help="Static GTFS: a .zip file or a folder of .txt files")
    p.add_argument("--rt", required=True, nargs="+", help="Realtime vehicle positions: files, folders, or glob patterns")
    p.add_argument("--date", required=True, nargs="+", help="Service date(s), YYYY-MM-DD")
    p.add_argument("--config", help="Feed config YAML (agency quirks and thresholds). Optional.")
    p.add_argument("--rt-format", choices=["auto", "pb", "flat_parquet", "table"], help="Override the config/auto-detected format")
    p.add_argument("--out", default="output", help="Output folder (default: output)")
    p.add_argument("--no-report", action="store_true", help="Skip the HTML report")
    p.add_argument("-v", "--verbose", action="store_true")
    return p.parse_args(argv)


def run_day(feed: StaticFeed, fixes, d: date, cfg, out_root: Path, extra_qc: Optional[dict] = None,
            report: bool = True):
    """Reconstruct one service date and write all outputs. Returns (result, output folder)."""
    result = reconstruct_day(feed, fixes, d, cfg)
    result.qc.update({**(extra_qc or {}), "static_warnings": feed.warnings, "config_hash": cfg.config_hash(),
                      "static_feed_hash": feed.content_hash, "algorithm_version": ALGORITHM_VERSION})
    day_dir = out_root / cfg.feed_id / d.isoformat()
    write_day(result, day_dir, feed.tz, cfg)
    if report:
        tp = timepoint_departures(result.events, feed.tz, cfg)
        build_report(tp, cfg.feed_id, str(feed.tz), d, d, day_dir / "report.html", route_names(feed))
    return result, day_dir


def route_names(feed: StaticFeed) -> dict:
    r = feed.route_info()
    return {rid: (row.route_long_name or "") for rid, row in r.iterrows()}


def print_day(result, day_dir: Path) -> None:
    q = result.qc
    pct = 100 * q["stop_visits_timed"] / max(1, q["stop_visits"])
    print(f"{q['service_date']}: {q['trips_with_gps']}/{q['trips_scheduled']} trips with realtime data, "
          f"{q['stop_visits_timed']}/{q['stop_visits']} stop visits timed ({pct:.0f}%). Output: {day_dir}")
    if q["rt_trip_ids_not_in_static"]:
        print(f"  warning: {q['rt_trip_ids_not_in_static']} realtime trip IDs are not in this GTFS "
              f"(e.g. {q['rt_trip_ids_not_in_static_examples'][:3]}). Is this the right schedule version?")


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s %(message)s", stream=sys.stderr)
    log = logging.getLogger("tdp")
    cfg = load_config(args.config)
    if args.rt_format:
        cfg.rt_format = args.rt_format

    try:
        feed = StaticFeed.load(args.gtfs, cfg.timezone, cfg.timepoint_rule, cfg.thresholds.stop_snap_m)
        log.info("static_loaded source=%s hash=%s tz=%s trips=%d", feed.source, feed.content_hash, feed.tz, len(feed.tables["trips"]))
        dates = [date.fromisoformat(ds) for ds in args.date]
        windows = [w for w in (service_window(feed, d, cfg.thresholds) for d in dates) if w]
        window = (min(w[0] for w in windows), max(w[1] for w in windows)) if windows else None
        fixes, rt_stats, fmt = load_vehicle_fixes(args.rt, cfg, window)  # only the records these dates need
    except (FileNotFoundError, ValueError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    log.info("realtime_loaded format=%s %s", fmt, json.dumps(rt_stats))
    if not len(fixes):
        log.error("No usable vehicle positions were found in %s", args.rt)
        return 2

    for ds in args.date:
        result, day_dir = run_day(feed, fixes, date.fromisoformat(ds), cfg, Path(args.out),
                                  {"realtime_format": fmt, **rt_stats}, report=not args.no_report)
        print_day(result, day_dir)
    return 0
