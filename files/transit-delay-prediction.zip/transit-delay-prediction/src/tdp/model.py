"""Predict how late each run will leave each timepoint, learned from past days.

Example:
    python -m tdp.model --history output/bcrta/history_2026-08-23_to_2026-09-22/leave_times.parquet

Reads the simple leave-time table (leave_times.parquet or .csv) produced by `python -m tdp.history`
and writes, next to it in a `model/` folder:

    predictions.csv   one row per run, timepoint and weekday: scheduled leave, predicted typical
                      minutes late, a "late day" value (80% of days are at or below it), and the
                      predicted leave times
    evaluation.csv    how accurate the model was on the most recent days it was NOT trained on,
                      compared with two simple alternatives

How it is kept honest:
* Only information known before the day is used: route, run (trip_id), timepoint, position in
  the trip, scheduled time, and day of the week. Nothing from the day being predicted.
* Accuracy is measured by training on earlier days and testing on the latest `--test-days` days.
* It is compared with (1) "the bus leaves exactly on schedule" and (2) "the same as this run's
  typical lateness so far". If the model does not beat (2), use (2).

Engine: LightGBM. If LightGBM cannot be loaded (on macOS it needs `brew install libomp`),
scikit-learn's HistGradientBoostingRegressor, the same kind of model, is used instead.
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path
from typing import List, Optional, Tuple

import duckdb
import numpy as np
import pandas as pd

from .timeutil import format_gtfs_time, parse_gtfs_time

log = logging.getLogger("tdp.model")

CATEGORICAL = ["route", "trip_id", "stop_id", "weekday"]
NUMERIC = ["stop_sequence", "scheduled_secs"]
QUANTILES = {"typical": 0.5, "late_day": 0.8}
SEED = 0


# ----------------------------------------------------------------------------- data
def load_history(path: str) -> pd.DataFrame:
    p = Path(path)
    reader = f"read_parquet('{p.as_posix()}')" if p.suffix == ".parquet" else f"read_csv('{p.as_posix()}', all_varchar=true)"
    df = duckdb.sql(f"select * from {reader}").df()
    needed = {"service_date", "route", "trip_id", "stop_sequence", "stop_id", "scheduled_leave", "minutes_late"}
    missing = needed - set(df.columns)
    if missing:
        raise ValueError(f"{path} is missing column(s) {sorted(missing)}; use leave_times.parquet from tdp.history")
    df["service_date"] = pd.to_datetime(df.service_date).dt.date.astype(str)
    df["weekday"] = pd.to_datetime(df.service_date).dt.day_name()
    for c in ["route", "trip_id", "stop_id"]:
        df[c] = df[c].astype(str)
    if "stop_name" not in df.columns:
        df["stop_name"] = df.stop_id
    df["stop_sequence"] = pd.to_numeric(df.stop_sequence).astype(int)
    df["scheduled_secs"] = df.scheduled_leave.astype(str).map(parse_gtfs_time)
    df["minutes_late"] = pd.to_numeric(df.minutes_late, errors="coerce")
    return df


def features(df: pd.DataFrame, categories: Optional[dict] = None) -> Tuple[pd.DataFrame, dict]:
    """Model inputs. Category levels are fixed from training data so test/prediction rows match."""
    X = df[CATEGORICAL + NUMERIC].copy()
    categories = categories or {c: sorted(X[c].unique()) for c in CATEGORICAL}
    for c in CATEGORICAL:
        X[c] = pd.Categorical(X[c], categories=categories[c])
    return X, categories


# ----------------------------------------------------------------------------- engines
class QuantileModel:
    """One gradient-boosted model per quantile (0.5 = typical day, 0.8 = late day)."""

    def __init__(self, engine: str = "auto"):
        self.engine = self._pick(engine)
        self.models = {}
        self.categories: dict = {}

    @staticmethod
    def _pick(engine: str) -> str:
        if engine in ("auto", "lightgbm"):
            try:
                import lightgbm  # noqa: F401
                return "lightgbm"
            except (ImportError, OSError) as e:
                if engine == "lightgbm":
                    raise ImportError("LightGBM could not be loaded. On macOS run `brew install libomp`, "
                                      "or use --engine sklearn") from e
                log.warning("lightgbm_unavailable using=sklearn reason=%s", e)
        return "sklearn"

    def _new(self, alpha: float, n_rows: int):
        if self.engine == "lightgbm":
            import lightgbm as lgb
            return lgb.LGBMRegressor(objective="quantile", alpha=alpha, n_estimators=400, learning_rate=0.05,
                                     num_leaves=31, min_child_samples=max(5, min(20, n_rows // 200)),
                                     cat_smooth=10, random_state=SEED, n_jobs=1, deterministic=True,
                                     force_row_wise=True, verbose=-1)
        from sklearn.ensemble import HistGradientBoostingRegressor
        return HistGradientBoostingRegressor(loss="quantile", quantile=alpha, max_iter=400, learning_rate=0.05,
                                             random_state=SEED)

    def _prepare(self, X: pd.DataFrame) -> pd.DataFrame:
        if self.engine == "lightgbm":
            return X
        # scikit-learn's native categorical support is limited to 255 levels (there are more runs),
        # so categories are passed as integer codes.
        Z = X.copy()
        for c in CATEGORICAL:
            Z[c] = Z[c].cat.codes.astype(float)
        return Z

    def fit(self, df: pd.DataFrame) -> "QuantileModel":
        X, self.categories = features(df)
        y = df.minutes_late.to_numpy(float)
        for name, alpha in QUANTILES.items():
            self.models[name] = self._new(alpha, len(df)).fit(self._prepare(X), y)
        return self

    def predict(self, df: pd.DataFrame) -> pd.DataFrame:
        X, _ = features(df, self.categories)
        Z = self._prepare(X)
        out = pd.DataFrame({name: m.predict(Z) for name, m in self.models.items()}, index=df.index)
        out["late_day"] = np.maximum(out.late_day, out.typical)  # keep the two consistent
        return out


# ----------------------------------------------------------------------------- baselines
KEY = ["trip_id", "stop_id", "stop_sequence"]


def typical_so_far(train: pd.DataFrame, rows: pd.DataFrame) -> np.ndarray:
    """Baseline: this run's median lateness at this timepoint over the training days (0 if unseen)."""
    med = train.groupby(KEY).minutes_late.median().rename("m").reset_index()
    return rows[KEY].merge(med, on=KEY, how="left").m.fillna(0.0).to_numpy()


def _score(name: str, pred: np.ndarray, actual: np.ndarray) -> dict:
    err = np.abs(pred - actual)
    return {"method": name, "departures": int(len(actual)),
            "mean_error_min": round(float(err.mean()), 2),
            "median_error_min": round(float(np.median(err)), 2),
            "pct_within_2_min": round(float(100 * (err <= 2).mean()), 1)}


# ----------------------------------------------------------------------------- run
def run(history_path: str, out_dir: Optional[Path] = None, test_days: int = 7, min_days: int = 14,
        engine: str = "auto") -> Path:
    df = load_history(history_path)
    measured = df[df.minutes_late.notna()]
    days = sorted(measured.service_date.unique())
    if len(days) < min_days:
        raise ValueError(f"Only {len(days)} day(s) with measured leave times; at least {min_days} are needed "
                         f"to train and test a model. Run `python -m tdp.history` over a longer date range.")
    out_dir = out_dir or Path(history_path).parent / "model"
    out_dir.mkdir(parents=True, exist_ok=True)

    # 1. Honest evaluation: train on earlier days, test on the most recent ones.
    cut = days[-test_days]
    train, test = measured[measured.service_date < cut], measured[measured.service_date >= cut]
    model = QuantileModel(engine).fit(train)
    pred = model.predict(test)
    actual = test.minutes_late.to_numpy(float)
    rows = [
        _score("leaves exactly on schedule (0 min late)", np.zeros(len(test)), actual),
        _score("this run's typical lateness so far (median)", typical_so_far(train, test), actual),
        _score(f"model ({model.engine})", pred.typical.to_numpy(), actual),
    ]
    evaluation = pd.DataFrame(rows)
    evaluation["train_days"] = f"{days[0]} to {train.service_date.max()} ({len(days) - test_days} days)"
    evaluation["test_days"] = f"{cut} to {days[-1]} ({test_days} days)"
    evaluation["late_day_value_held"] = ""
    held = float(100 * (actual <= pred.late_day.to_numpy() + 1e-9).mean())
    evaluation.loc[2, "late_day_value_held"] = f"{held:.0f}% of test departures were at or below the late-day value (target 80%)"

    # 2. Final model on all days, predictions for every run/timepoint/weekday seen.
    final = QuantileModel(engine).fit(measured)
    grid_cols = ["route", "trip_id", "stop_sequence", "stop_id", "stop_name", "scheduled_leave", "scheduled_secs", "weekday"]
    grid = df[grid_cols].drop_duplicates().reset_index(drop=True)
    p = final.predict(grid)
    counts = measured.groupby(KEY + ["weekday"]).size().rename("days_measured").reset_index()
    grid = grid.merge(counts, on=KEY + ["weekday"], how="left")
    grid["days_measured"] = grid.days_measured.fillna(0).astype(int)
    order = {d: i for i, d in enumerate(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"])}
    predictions = pd.DataFrame({
        "route": grid.route, "trip_id": grid.trip_id, "stop_sequence": grid.stop_sequence, "stop_id": grid.stop_id,
        "stop_name": grid.stop_name, "weekday": grid.weekday, "scheduled_leave": grid.scheduled_leave,
        "predicted_minutes_late": p.typical.round(1), "late_day_minutes_late": p.late_day.round(1),
        "predicted_leave": [format_gtfs_time(int(round(s + 60 * m))) for s, m in zip(grid.scheduled_secs, p.typical)],
        "late_day_leave": [format_gtfs_time(int(round(s + 60 * m))) for s, m in zip(grid.scheduled_secs, p.late_day)],
        "days_measured": grid.days_measured,
    })
    predictions["_d"] = predictions.weekday.map(order)
    predictions = (predictions.sort_values(["route", "_d", "scheduled_leave", "trip_id", "stop_sequence"], kind="mergesort")
                              .drop(columns="_d").reset_index(drop=True))
    predictions.to_csv(out_dir / "predictions.csv", index=False)
    evaluation.to_csv(out_dir / "evaluation.csv", index=False)
    return out_dir


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(prog="tdp.model", description="Learn from past leave times and predict future ones.")
    ap.add_argument("--history", required=True, help="leave_times.parquet (or .csv) from python -m tdp.history")
    ap.add_argument("--out", help="Output folder (default: a model/ folder next to the history file)")
    ap.add_argument("--test-days", type=int, default=7, help="Most recent days held back to test accuracy (default 7)")
    ap.add_argument("--min-days", type=int, default=14, help="Minimum days of history required (default 14)")
    ap.add_argument("--engine", choices=["auto", "lightgbm", "sklearn"], default="auto")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.WARNING, format="%(levelname)s %(message)s", stream=sys.stderr)
    try:
        out = run(a.history, Path(a.out) if a.out else None, a.test_days, a.min_days, a.engine)
    except (FileNotFoundError, ValueError, ImportError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    ev = pd.read_csv(out / "evaluation.csv")
    print("Accuracy on the most recent days (not used for training):")
    for r in ev.itertuples():
        print(f"  {r.method:48s} average error {r.mean_error_min:5.2f} min, within 2 min {r.pct_within_2_min:5.1f}%")
    print(f"\nPredictions: {out / 'predictions.csv'}\nEvaluation:  {out / 'evaluation.csv'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
