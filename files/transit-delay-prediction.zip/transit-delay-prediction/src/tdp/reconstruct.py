"""Reconstruct stop events for one service date (architecture doc, sections 10-11).

Evidence hierarchy implemented here, per stop and per time kind:
  1. observed_stop_status   feed says STOPPED_AT this stop (only if the feed provides it)
  2. gps_dwell              >= min_dwell_fixes stationary fixes at the stop: arrival and departure
  3. gps_passage            time interpolated between two GPS fixes around the stop (passage only)
  -  none                   no time; the event stays in the table with status no_evidence

Nothing is ever copied from a prediction. Every time carries its method and an uncertainty.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .config import FeedConfig, Thresholds
from .geo import RoutePath
from .realtime import STOPPED_AT
from .static_gtfs import StaticFeed, TripSchedule
from .timeutil import adjacent_dates, service_day_anchor, to_yyyymmdd

log = logging.getLogger(__name__)
ALGORITHM_VERSION = "0.1.0"


@dataclass
class DayResult:
    events: pd.DataFrame
    trips: pd.DataFrame
    qc: Dict[str, object]
    anchor_unix: float
    coverage: Tuple[Optional[float], Optional[float]]  # first/last fix available_at (unix)


@dataclass
class TripFixes:
    vehicle_id: Optional[str]
    ts: np.ndarray
    dist: np.ndarray
    speed: np.ndarray
    status: np.ndarray
    stop_id: np.ndarray
    cur_seq: np.ndarray
    available_at: np.ndarray
    flags: List[str]

    @property
    def n(self) -> int:
        return len(self.ts)


EMPTY = np.empty(0)


# ----------------------------------------------------------------------------- service dates
def select_fixes_for_date(fixes: pd.DataFrame, feed: StaticFeed, d: date,
                          th: Thresholds) -> Tuple[pd.DataFrame, Dict[str, int]]:
    """Keep fixes belonging to trips of service date d.

    start_date from the feed wins. Without it, the fix goes to whichever of d-1, d, d+1 has the
    trip active and a scheduled window closest to the fix time (handles trips after midnight).
    """
    ymd = to_yyyymmdd(d)
    has_date = fixes.start_date != ""
    direct = fixes[has_date & (fixes.start_date == ymd) & (fixes.trip_id != "")]
    undated = fixes[~has_date & (fixes.trip_id != "")]
    inferred = undated.iloc[0:0]
    if len(undated):
        best = pd.Series(np.inf, index=undated.index)
        best_date = pd.Series("", index=undated.index)
        wanted = set(undated.trip_id)
        for cand in adjacent_dates(d):
            trips = feed.trips_on(cand)
            trips = trips[trips.trip_id.isin(wanted)]
            anchor = service_day_anchor(cand, feed.tz)
            win = {}
            for _, row in trips.iterrows():
                s = feed.schedule(row)
                if s is not None:
                    win[row.trip_id] = (anchor + s.first_secs, anchor + s.last_secs)
            lo = undated.trip_id.map(lambda t: win.get(t, (np.nan, np.nan))[0]).astype(float)
            hi = undated.trip_id.map(lambda t: win.get(t, (np.nan, np.nan))[1]).astype(float)
            dist = np.maximum(np.maximum(lo - undated.ts, undated.ts - hi), 0).fillna(np.inf)
            better = dist < best
            best[better] = dist[better]
            best_date[better] = to_yyyymmdd(cand)
        inferred = undated[(best_date == ymd) & (best <= th.service_date_tolerance_s)]
    stats = {"fixes_for_date_direct": int(len(direct)), "fixes_for_date_inferred": int(len(inferred))}
    return pd.concat([direct, inferred]).sort_values(["trip_id", "ts"], kind="mergesort"), stats


def service_window(feed: StaticFeed, d: date, th: Thresholds) -> Optional[Tuple[float, float]]:
    """Unix time range of realtime data needed to reconstruct service date d (None if no service)."""
    anchor = service_day_anchor(d, feed.tz)
    first, last = None, None
    for _, trip in feed.trips_on(d).iterrows():
        s = feed.schedule(trip)
        if s is None:
            continue
        first = s.first_secs if first is None else min(first, s.first_secs)
        last = s.last_secs if last is None else max(last, s.last_secs)
    if first is None:
        return None
    before = max(th.service_date_tolerance_s, th.terminal_borrow_before_s) + th.max_fix_age_s
    after = max(th.service_date_tolerance_s, th.terminal_borrow_after_s) + th.max_fix_age_s
    return anchor + first - before, anchor + last + after


# ----------------------------------------------------------------------------- fixes -> path
def _first_valid(a: np.ndarray, reverse: bool = False) -> float:
    seq = a[::-1] if reverse else a
    for v in seq:
        if v == v:
            return float(v)
    return float("nan")


def project_trip_fixes(trip_id: str, f: Optional[pd.DataFrame], vehicle_fixes: Dict[str, pd.DataFrame],
                       sched: TripSchedule, path: RoutePath, feed: StaticFeed, th: Thresholds) -> TripFixes:
    flags: List[str] = []
    if f is None or not len(f):
        return TripFixes(None, EMPTY, EMPTY, EMPTY, EMPTY, EMPTY, EMPTY, EMPTY, flags)
    counts = f.vehicle_id.value_counts()
    vehicle = str(counts.index[0])
    if len(counts) > 1:
        flags.append("multi_vehicle")
        f = f[f.vehicle_id == vehicle]
    f = f.sort_values("ts", kind="mergesort")
    dists = sched.stops.stop_dist_m.to_numpy(float)
    first_sd, last_sd = _first_valid(dists), _first_valid(dists, reverse=True)
    t0, t1 = float(f.ts.iloc[0]), float(f.ts.iloc[-1])

    # The same bus's fixes just before/after this trip: trip_id often switches at the terminal,
    # so these are what let us time the first-stop departure and last-stop arrival.
    vf = vehicle_fixes.get(vehicle)
    pre = post = f.iloc[0:0]
    if vf is not None:
        pre = vf[(vf.ts >= t0 - th.terminal_borrow_before_s) & (vf.ts < t0) & (vf.trip_id != trip_id)]
        post = vf[(vf.ts > t1) & (vf.ts <= t1 + th.terminal_borrow_after_s) & (vf.trip_id != trip_id)]

    cols = {k: [] for k in ["ts", "dist", "speed", "status", "stop_id", "cur_seq", "available_at"]}

    def add(r, dist):
        cols["ts"].append(float(r.ts)); cols["dist"].append(dist); cols["speed"].append(float(r.speed))
        cols["status"].append(float(r.current_status)); cols["stop_id"].append(r.stop_id)
        cols["cur_seq"].append(float(r.current_stop_sequence)); cols["available_at"].append(float(r.available_at))

    proj = feed.projector
    if first_sd == first_sd:
        for r in pre.itertuples():
            c = path.candidates(*[float(v) for v in proj.xy(r.lat, r.lon)], th.max_cross_track_m)
            c = c[c <= first_sd + th.stop_radius_m]
            if len(c):
                add(r, float(c[0]))

    prev_d = cols["dist"][-1] if cols["dist"] else -np.inf
    prev_t = cols["ts"][-1] if cols["ts"] else None
    off_route = backwards = 0
    for is_post, frame in ((False, f), (True, post)):
        for r in frame.itertuples():
            c = path.candidates(*[float(v) for v in proj.xy(r.lat, r.lon)], th.max_cross_track_m)
            if not len(c):
                if is_post:
                    break
                off_route += 1
                continue
            c = c[c >= prev_d - th.jitter_m]
            if prev_t is not None:
                c = c[c - max(prev_d, 0) <= th.max_speed_mps * max(r.ts - prev_t, 0) + 100]
            if is_post:
                c = c[c >= last_sd - 150] if last_sd == last_sd else c[:0]
            if not len(c):
                if is_post:
                    break
                backwards += 1
                continue
            dist = max(float(c[0]), prev_d)  # clamp small backward jitter
            add(r, dist)
            prev_d, prev_t = dist, float(r.ts)

    if off_route:
        flags.append(f"off_route_fixes={off_route}")
    if backwards:
        flags.append(f"rejected_fixes={backwards}")
    arr = {k: np.array(v, dtype=object if k == "stop_id" else float) for k, v in cols.items()}
    if len(arr["dist"]):
        arr["dist"] = np.maximum.accumulate(arr["dist"])
    return TripFixes(vehicle, arr["ts"], arr["dist"], arr["speed"], arr["status"], arr["stop_id"],
                     arr["cur_seq"], arr["available_at"], flags)


# ----------------------------------------------------------------------------- evidence
def crossing(tf: TripFixes, target: float, max_gap: float):
    """(time, uncertainty_s, index_of_later_fix) when the bus first reached `target` metres."""
    idx = np.flatnonzero(tf.dist >= target)
    if not len(idx) or idx[0] == 0:
        return None
    j = int(idx[0])
    t0, t1, d0, d1 = tf.ts[j - 1], tf.ts[j], tf.dist[j - 1], tf.dist[j]
    gap = t1 - t0
    if gap > max_gap or gap <= 0 or d1 == d0:
        return None
    return t0 + gap * (target - d0) / (d1 - d0), gap / 2.0, j


def _observed(tf: TripFixes, seq: int, stop_id: str, max_gap: float):
    match = (tf.status == STOPPED_AT) & (
        (tf.cur_seq == seq) | (np.isnan(tf.cur_seq) & (tf.stop_id == stop_id)))
    idx = np.flatnonzero(match)
    if not len(idx):
        return None, None
    a, b = int(idx[0]), int(idx[-1])
    arr = dep = None
    if a > 0 and tf.ts[a] - tf.ts[a - 1] <= max_gap:
        g = tf.ts[a] - tf.ts[a - 1]
        arr = (tf.ts[a] - g / 2, g / 2, a)
    if b + 1 < tf.n and tf.ts[b + 1] - tf.ts[b] <= max_gap:
        g = tf.ts[b + 1] - tf.ts[b]
        dep = (tf.ts[b] + g / 2, g / 2, b + 1)
    return arr, dep


def stop_evidence(tf: TripFixes, stops: pd.DataFrame, th: Thresholds) -> List[Dict[str, object]]:
    n = len(stops)
    out: List[Dict[str, object]] = []
    for i, s in enumerate(stops.itertuples()):
        ev: Dict[str, object] = {"arrival": None, "departure": None, "passage": None,
                                 "arrival_method": None, "departure_method": None, "passage_method": None,
                                 "flags": []}
        sd = s.stop_dist_m
        first, last = i == 0, i == n - 1
        if tf.n >= 2 and sd == sd:
            near = np.abs(tf.dist - sd) <= th.stop_radius_m
            stationary = near & (tf.speed <= th.stationary_speed_mps)
            obs_arr, obs_dep = _observed(tf, int(s.stop_sequence), s.stop_id, th.max_interp_gap_s)
            if obs_arr or obs_dep:
                if not first and obs_arr:
                    ev["arrival"], ev["arrival_method"] = obs_arr, "observed_stop_status"
                if not last and obs_dep:
                    ev["departure"], ev["departure_method"] = obs_dep, "observed_stop_status"
            elif first:
                dep = crossing(tf, sd + th.stop_radius_m, th.max_interp_gap_s)
                if dep:
                    ev["departure"], ev["departure_method"] = dep, ("gps_dwell" if stationary.any() else "gps_passage")
            elif last:
                arr = crossing(tf, sd - th.stop_radius_m, th.max_interp_gap_s)
                if arr:
                    ev["arrival"], ev["arrival_method"] = arr, ("gps_dwell" if stationary.any() else "gps_passage")
            elif stationary.sum() >= th.min_dwell_fixes:
                arr = crossing(tf, sd - th.stop_radius_m, th.max_interp_gap_s)
                dep = crossing(tf, sd + th.stop_radius_m, th.max_interp_gap_s)
                if arr:
                    ev["arrival"], ev["arrival_method"] = arr, "gps_dwell"
                if dep:
                    ev["departure"], ev["departure_method"] = dep, "gps_dwell"

            # Passage: departure if known, else arrival at the last stop, else the moment
            # the bus crossed the stop's position.
            if ev["departure"]:
                ev["passage"], ev["passage_method"] = ev["departure"], ev["departure_method"]
            elif last and ev["arrival"]:
                ev["passage"], ev["passage_method"] = ev["arrival"], ev["arrival_method"]
            else:
                p = crossing(tf, sd, th.max_interp_gap_s)
                if p:
                    ev["passage"], ev["passage_method"] = p, "gps_passage"
        elif sd != sd:
            ev["flags"].append("stop_not_on_path")
        out.append(ev)
    return out


# ----------------------------------------------------------------------------- day
def reconstruct_day(feed: StaticFeed, fixes: pd.DataFrame, d: date, cfg: FeedConfig) -> DayResult:
    th = cfg.thresholds
    anchor = service_day_anchor(d, feed.tz)
    day_fixes, date_stats = select_fixes_for_date(fixes, feed, d, th)
    trip_groups = dict(tuple(day_fixes.groupby("trip_id", sort=False)))
    vehicle_fixes = dict(tuple(fixes.groupby("vehicle_id", sort=False)))
    trips = feed.trips_on(d)
    routes = feed.route_info()

    static_ids = set(feed.tables["trips"].trip_id)
    rt_ids = set(day_fixes.trip_id)
    unmatched = sorted(rt_ids - static_ids)

    ev_rows: List[Dict[str, object]] = []
    trip_rows: List[Dict[str, object]] = []
    skipped_no_schedule = 0
    for _, trip in trips.sort_values("trip_id").iterrows():
        sched = feed.schedule(trip)
        if sched is None:
            skipped_no_schedule += 1
            continue
        path = feed._paths[sched.shape_key]
        tf = project_trip_fixes(trip.trip_id, trip_groups.get(trip.trip_id), vehicle_fixes, sched, path, feed, th)
        evidence = stop_evidence(tf, sched.stops, th)
        route = routes.loc[sched.route_id] if sched.route_id in routes.index else None

        last_pass = -np.inf
        timed = 0
        for s, ev in zip(sched.stops.itertuples(), evidence):
            sched_arr = anchor + s.arr_secs
            sched_dep = anchor + s.dep_secs
            flags = list(ev["flags"])
            p = ev["passage"]
            if p is not None and not (th.plausible_min_delay_s <= p[0] - sched_dep <= th.plausible_max_delay_s):
                ev.update(arrival=None, departure=None, passage=None)
                flags.append("implausible_time")
                p = None
            if p is not None:
                if p[0] < last_pass - 5:
                    ev.update(arrival=None, departure=None, passage=None)
                    flags.append("non_monotone")
                    p = None
                else:
                    last_pass = p[0]

            def val(k):
                return None if ev[k] is None else float(ev[k][0])

            def unc(k):
                return None if ev[k] is None else round(float(ev[k][1]), 1)

            def knowable(k):
                return None if ev[k] is None else float(tf.available_at[ev[k][2]])

            arr_t, dep_t, pas_t = val("arrival"), val("departure"), val("passage")
            if pas_t is not None:
                status = "served"
                timed += 1
            elif tf.n == 0:
                status = "no_data"
            else:
                status = "no_evidence"
            kn = [x for x in (knowable("arrival"), knowable("departure"), knowable("passage")) if x is not None]
            ev_rows.append({
                "feed_id": cfg.feed_id,
                "service_date": d.isoformat(),
                "trip_id": sched.trip_id,
                "route_id": sched.route_id,
                "route_short_name": (route.route_short_name if route is not None else "") or "",
                "direction_id": sched.direction_id,
                "block_id": sched.block_id,
                "vehicle_id": tf.vehicle_id,
                "stop_sequence": int(s.stop_sequence),
                "stop_id": s.stop_id,
                "stop_name": s.stop_name,
                "is_timepoint": bool(s.is_timepoint),
                "is_first_stop": bool(s.Index == 0),
                "is_last_stop": bool(s.Index == len(sched.stops) - 1),
                "sched_interpolated": bool(s.sched_interpolated),
                "scheduled_arrival_secs": int(s.arr_secs),
                "scheduled_departure_secs": int(s.dep_secs),
                "scheduled_arrival_unix": sched_arr,
                "scheduled_departure_unix": sched_dep,
                "event_status": status,
                "arrival_unix": arr_t,
                "arrival_method": ev["arrival_method"] if arr_t is not None else None,
                "arrival_uncertainty_s": unc("arrival"),
                "departure_unix": dep_t,
                "departure_method": ev["departure_method"] if dep_t is not None else None,
                "departure_uncertainty_s": unc("departure"),
                "passage_unix": pas_t,
                "passage_method": ev["passage_method"] if pas_t is not None else None,
                "passage_uncertainty_s": unc("passage"),
                "arrival_delay_s": None if arr_t is None else int(round(arr_t - sched_arr)),
                "departure_delay_s": None if dep_t is None else int(round(dep_t - sched_dep)),
                "passage_delay_s": None if pas_t is None else int(round(pas_t - sched_dep)),
                "knowable_at_unix": max(kn) if kn else None,
                "qc_flags": ";".join(flags + tf.flags + (["synthetic_path"] if path.synthetic else [])),
                "algorithm_version": ALGORITHM_VERSION,
                "config_hash": cfg.config_hash(),
                "static_feed_hash": feed.content_hash,
            })
        trip_rows.append({
            "service_date": d.isoformat(), "trip_id": sched.trip_id, "route_id": sched.route_id,
            "direction_id": sched.direction_id, "block_id": sched.block_id, "vehicle_id": tf.vehicle_id,
            "fixes_used": tf.n, "stops": len(sched.stops), "stops_timed": timed,
            "status": "no_data" if tf.n == 0 else ("operated" if timed else "no_evidence"),
            "qc_flags": ";".join(tf.flags),
        })

    events = pd.DataFrame(ev_rows)
    if len(events):
        events = events.sort_values(["trip_id", "stop_sequence"], kind="mergesort").reset_index(drop=True)
    trips_df = pd.DataFrame(trip_rows)
    served = events.event_status.eq("served") if len(events) else pd.Series(dtype=bool)
    qc: Dict[str, object] = {
        **date_stats,
        "service_date": d.isoformat(),
        "trips_scheduled": int(len(trips)),
        "trips_skipped_no_schedule": skipped_no_schedule,
        "trips_with_gps": int((trips_df.fixes_used > 0).sum()) if len(trips_df) else 0,
        "stop_visits": int(len(events)),
        "stop_visits_timed": int(served.sum()),
        "rt_trip_ids_not_in_static": len(unmatched),
        "rt_trip_ids_not_in_static_examples": unmatched[:10],
        "methods_passage": events.passage_method.value_counts().to_dict() if len(events) else {},
        "flags_non_monotone": int(events.qc_flags.str.contains("non_monotone").sum()) if len(events) else 0,
        "flags_implausible": int(events.qc_flags.str.contains("implausible_time").sum()) if len(events) else 0,
    }
    cov = (float(day_fixes.available_at.min()), float(day_fixes.available_at.max())) if len(day_fixes) else (None, None)
    log.info("reconstructed date=%s trips=%d visits=%d timed=%d", d, len(trips_df), len(events), int(served.sum()))
    return DayResult(events=events, trips=trips_df, qc=qc, anchor_unix=anchor, coverage=cov)
