"""Linear referencing: place GPS points and stops at a distance (metres) along a route path.

A local equirectangular projection is used. Across a single agency's service area
(tens of km) its distance error is well under 0.5%, which is negligible next to GPS noise,
and it keeps the dependency list small (no GEOS/PROJ).
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

R_EARTH = 6371000.0


class Projector:
    def __init__(self, lat0_deg: float):
        self.lat0_deg = float(lat0_deg)
        self._kx = R_EARTH * math.cos(math.radians(lat0_deg))

    def xy(self, lat, lon):
        lat = np.asarray(lat, dtype=float)
        lon = np.asarray(lon, dtype=float)
        return np.radians(lon) * self._kx, np.radians(lat) * R_EARTH

    def latlon(self, x, y):
        return np.degrees(np.asarray(y, float) / R_EARTH), np.degrees(np.asarray(x, float) / self._kx)


@dataclass
class RoutePath:
    x: np.ndarray
    y: np.ndarray
    cum: np.ndarray          # cumulative distance (m) at each vertex
    synthetic: bool = False  # True when built from stop coordinates because the feed has no shape

    @property
    def length(self) -> float:
        return float(self.cum[-1]) if len(self.cum) else 0.0

    def candidates(self, px: float, py: float, max_cross_m: float) -> np.ndarray:
        """Sorted distances-along of every segment projection within max_cross_m of the point.

        Returning *all* nearby candidates (not just the nearest) is what lets callers pick the
        one consistent with forward progress on loops and routes that double back.
        """
        if len(self.x) == 1:
            d = math.hypot(px - self.x[0], py - self.y[0])
            return np.array([0.0]) if d <= max_cross_m else np.empty(0)
        ax, ay = self.x[:-1], self.y[:-1]
        dx, dy = np.diff(self.x), np.diff(self.y)
        seg2 = dx * dx + dy * dy
        safe = np.where(seg2 > 0, seg2, 1.0)
        t = np.clip(((px - ax) * dx + (py - ay) * dy) / safe, 0.0, 1.0)
        t = np.where(seg2 > 0, t, 0.0)
        cx, cy = ax + t * dx, ay + t * dy
        cross = np.hypot(px - cx, py - cy)
        along = self.cum[:-1] + t * np.sqrt(seg2)
        keep = cross <= max_cross_m
        if not keep.any():
            return np.empty(0)
        along, cross = along[keep], cross[keep]
        order = np.argsort(along, kind="mergesort")
        along, cross = along[order], cross[order]
        # Neighbouring segments near a vertex both "see" the point (one via a clamped endpoint).
        # Group candidates that belong to the same pass of the path and keep the closest one,
        # while separate passes (loops, out-and-back) stay separate candidates.
        breaks = np.flatnonzero(np.diff(along) > 2 * max_cross_m) + 1
        return np.array([g_along[np.argmin(g_cross)]
                         for g_along, g_cross in zip(np.split(along, breaks), np.split(cross, breaks))])


def build_path(proj: Projector, lats, lons, synthetic: bool = False) -> RoutePath:
    x, y = proj.xy(lats, lons)
    if len(x) > 1:  # drop consecutive duplicate vertices
        keep = np.r_[True, (np.diff(x) != 0) | (np.diff(y) != 0)]
        x, y = x[keep], y[keep]
    cum = np.r_[0.0, np.cumsum(np.hypot(np.diff(x), np.diff(y)))] if len(x) else np.empty(0)
    return RoutePath(x=x, y=y, cum=cum, synthetic=synthetic)


def place_monotone(path: RoutePath, xs, ys, max_cross_m: float) -> np.ndarray:
    """Place an ordered sequence of points (e.g. a trip's stops) monotonically along the path.

    Each point takes the earliest candidate at or beyond the previous point's position, so a
    stop visited twice on a loop gets two different distances. NaN where no candidate exists.
    """
    out = np.full(len(xs), np.nan)
    prev = -np.inf
    for i, (px, py) in enumerate(zip(xs, ys)):
        c = path.candidates(float(px), float(py), max_cross_m)
        c = c[c >= prev]
        if len(c):
            out[i] = c[0]
            prev = c[0]
    return out
