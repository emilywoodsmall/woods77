"""Build a multi-day history of timepoint leave times.

With your own realtime files (a folder of .pb snapshots, archive Parquet, or your own CSV/Parquet):
    python -m tdp.history --start 2026-09-01 --end 2026-09-30 --gtfs gtfs.zip --rt my_files/

Files are indexed once and read one service day at a time, so long periods fit in memory.
Without --rt, days are downloaded from a public archive set in the config (optional).

For each service date this runs the single-day reconstruction (python -m tdp) and keeps its
output folder. Days already processed with the same schedule, config and code are reused, so
rerunning to add new days is fast. Output, in <out>/<feed_id>/history_<start>_to_<end>/:
    leave_times.csv / .parquet   one row per run, timepoint and day: scheduled vs actual leave time
    leave_times_by_run.csv       one row per run and timepoint, one column per day (minutes late)
    report.html                  route-by-route comparison chart and table
    details/                     full-detail table and per-day data-coverage summary
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from datetime import date, timedelta
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

from .archive import files_for_service_date
from .cli import route_names, run_day
from .config import FeedConfig, load_config
from .outputs import leave_times_by_run, simple_leave_times, write_timepoints_parquet
from .realtime import COLUMNS, RealtimeSource, load_vehicle_fixes
from .reconstruct import ALGORITHM_VERSION, service_window
from .report import build_report
from .static_gtfs import StaticFeed

log = logging.getLogger("tdp.history")

SUMMARY_COLUMNS = ["service_date", "weekday", "status", "trips_scheduled", "trips_with_data",
                   "timepoint_departures_scheduled", "timepoint_departures_measured",
                   "left_early", "left_on_time", "left_late", "pct_measured", "note"]


def daterange(start: date, end: date):
    d = start
    while d <= end:
        yield d
        d += timedelta(days=1)


def _cached(day_dir: Path, feed: StaticFeed, cfg: FeedConfig) -> bool:
    qc_path = day_dir / "qc_summary.json"
    if not (qc_path.exists() and (day_dir / "timepoint_departures.csv").exists()):
        return False
    qc = json.loads(qc_path.read_text())
    if not qc.get("trips_with_gps"):
        return False  # never reuse an empty day: data may have been added since
    return (qc.get("config_hash") == cfg.config_hash() and qc.get("static_feed_hash") == feed.content_hash
            and qc.get("algorithm_version") == ALGORITHM_VERSION)


def _day_summary(d: date, status: str, tp: Optional[pd.DataFrame], qc: Optional[dict], note: str = "") -> Dict:
    row = {"service_date": d.isoformat(), "weekday": d.strftime("%A"), "status": status, "note": note,
           "trips_scheduled": None, "trips_with_data": None, "timepoint_departures_scheduled": 0,
           "timepoint_departures_measured": 0, "left_early": 0, "left_on_time": 0, "left_late": 0,
           "pct_measured": None}
    if qc:
        row["trips_scheduled"] = qc.get("trips_scheduled")
        row["trips_with_data"] = qc.get("trips_with_gps")
    if tp is not None and len(tp):
        row["timepoint_departures_scheduled"] = int(len(tp))
        row["timepoint_departures_measured"] = int(tp.deviation_s.notna().sum())
        for k, col in (("early", "left_early"), ("on_time", "left_on_time"), ("late", "left_late")):
            row[col] = int((tp.status == k).sum())
        row["pct_measured"] = round(100 * row["timepoint_departures_measured"] / len(tp), 1)
        if status.startswith("ok") and row["pct_measured"] < 50 and not note:
            row["note"] = (f"Only {row['pct_measured']}% of departures measured; the realtime files may not "
                           f"cover the whole day.")
    return row


def build_history(start: date, end: date, gtfs: str, cfg: FeedConfig, out_root: Path,
                  rt_paths: Optional[List[str]] = None, cache_dir: Optional[Path] = None,
                  force: bool = False, day_reports: bool = True) -> Path:
    feed = StaticFeed.load(gtfs, cfg.timezone, cfg.timepoint_rule, cfg.thresholds.stop_snap_m)
    cache_dir = cache_dir or Path("data/archive") / cfg.feed_id
    summaries: List[Dict] = []
    frames: List[pd.DataFrame] = []
    # Your own files (--rt) are indexed once and then read one service day at a time, so long
    # periods do not need to fit in memory. Without --rt, days are downloaded from the archive.
    source = RealtimeSource(rt_paths, cfg) if rt_paths else None

    for d in daterange(start, end):
        day_dir = out_root / cfg.feed_id / d.isoformat()
        if not feed.active_service_ids(d):
            summaries.append(_day_summary(d, "no_schedule", None, None,
                                          "The GTFS file has no service on this date (outside its calendar)."))
            print(f"{d}: skipped, no service in this GTFS")
            continue
        if not force and _cached(day_dir, feed, cfg):
            status = "ok (reused)"
        else:
            window = service_window(feed, d, cfg.thresholds)
            if source is not None:
                fixes, stats = source.load(window)
                extra = {"realtime_format": source.format, **stats}
            else:
                files = files_for_service_date(cfg.archive, d, cache_dir)
                if files:
                    fixes, stats, fmt = load_vehicle_fixes([str(f) for f in files], cfg, window)
                    extra = {"realtime_format": fmt, "realtime_files": [str(f) for f in files], **stats}
                else:
                    fixes, extra = pd.DataFrame(columns=COLUMNS), {"realtime_files": []}
            # Days without realtime records are still written, so every scheduled departure appears
            # in the output with an empty actual time instead of silently disappearing.
            result, day_dir = run_day(feed, fixes, d, cfg, out_root, extra, report=day_reports)
            status = "ok"
        qc = json.loads((day_dir / "qc_summary.json").read_text())
        tp = pd.read_csv(day_dir / "timepoint_departures.csv", dtype={"trip_id": str, "stop_id": str,
                                                                        "route_id": str, "vehicle_id": str, "block_id": str,
                                                                        "direction_id": str})
        note = ""
        if qc.get("fixes_kept", 0) == 0:
            status, note = "no_realtime_data", "No realtime records for this day in the files given or downloaded."
        elif qc.get("trips_with_gps", 0) == 0:
            status, note = "no_matching_data", "Realtime data had no trips matching this schedule."
        elif qc.get("rt_trip_ids_not_in_static", 0):
            note = f"{qc['rt_trip_ids_not_in_static']} realtime trip IDs not in this GTFS."
        summaries.append(_day_summary(d, status, tp, qc, note))
        if len(tp):
            frames.append(tp)
        s = summaries[-1]
        print(f"{d}: {status}, {s['timepoint_departures_measured']}/{s['timepoint_departures_scheduled']} "
              f"timepoint departures measured")

    hist_dir = out_root / cfg.feed_id / f"history_{start.isoformat()}_to_{end.isoformat()}"
    details = hist_dir / "details"
    details.mkdir(parents=True, exist_ok=True)
    history = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
    if len(history):
        history = history.sort_values(["service_date", "trip_id", "stop_sequence"], kind="mergesort")
    simple = simple_leave_times(history)
    # The three files most people need:
    _write_csv(simple, hist_dir / "leave_times.csv")
    _write_csv(leave_times_by_run(simple), hist_dir / "leave_times_by_run.csv")
    build_report(history, cfg.feed_id, str(feed.tz), start, end, hist_dir / "report.html", route_names(feed))
    # Supporting files:
    if len(simple):
        _write_parquet(simple, hist_dir / "leave_times.parquet")
        write_timepoints_parquet(history, details / "timepoint_departures.parquet")
    _write_csv(history, details / "timepoint_departures.csv")
    _write_csv(pd.DataFrame(summaries, columns=SUMMARY_COLUMNS), details / "daily_summary.csv")
    return hist_dir


def _write_parquet(df: pd.DataFrame, path: Path) -> None:
    import duckdb
    tmp = path.with_name(path.name + ".tmp")
    con = duckdb.connect()
    con.register("t", df)
    con.execute(f"copy (select * replace (service_date::DATE as service_date) from t) to '{tmp.as_posix()}' (format parquet)")
    con.close()
    os.replace(tmp, path)


def _write_csv(df: pd.DataFrame, path: Path) -> None:
    tmp = path.with_name(path.name + ".tmp")
    df.to_csv(tmp, index=False, float_format="%.1f")
    os.replace(tmp, path)


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(prog="tdp.history", description="Build a multi-day history of timepoint leave times.")
    p.add_argument("--start", required=True, help="First service date, YYYY-MM-DD")
    p.add_argument("--end", required=True, help="Last service date, YYYY-MM-DD")
    p.add_argument("--gtfs", required=True, help="Static GTFS .zip or folder in effect for these dates")
    p.add_argument("--config", help="Feed config YAML (needs archive.vehicle_positions_url to download)")
    p.add_argument("--rt", nargs="+", help="Your realtime files/folders (.pb, .parquet, .csv). If omitted, download from the archive in the config")
    p.add_argument("--out", default="output", help="Output folder (default: output)")
    p.add_argument("--cache", help="Where downloaded archive files are kept (default: data/archive/<feed_id>)")
    p.add_argument("--force", action="store_true", help="Reprocess days even if already done")
    p.add_argument("--no-day-reports", action="store_true", help="Skip the per-day report.html files")
    p.add_argument("-v", "--verbose", action="store_true")
    a = p.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if a.verbose else logging.WARNING,
                        format="%(asctime)s %(levelname)s %(name)s %(message)s", stream=sys.stderr)
    cfg = load_config(a.config)
    start, end = date.fromisoformat(a.start), date.fromisoformat(a.end)
    if end < start:
        print("error: --end is before --start", file=sys.stderr)
        return 2
    if not a.rt and not cfg.archive.vehicle_positions_url:
        print("error: give --rt files, or set archive.vehicle_positions_url in the config", file=sys.stderr)
        return 2
    try:
        hist_dir = build_history(start, end, a.gtfs, cfg, Path(a.out), a.rt,
                                 Path(a.cache) if a.cache else None, a.force, not a.no_day_reports)
    except (FileNotFoundError, ValueError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    print(f"\nHistory written to {hist_dir}\nOpen {hist_dir / 'report.html'} in a browser.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
