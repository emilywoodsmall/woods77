"""Build the plain HTML report: route-by-route comparison chart and table of every departure.

The same report is used for one day (python -m tdp) and for a date range (python -m tdp.history).
Analysis is intentionally left out; use the Parquet/CSV outputs for that.
"""
from __future__ import annotations

import json
from datetime import date
from pathlib import Path
from typing import Dict, Optional

import pandas as pd


def report_payload(tp: pd.DataFrame, feed_id: str, timezone: str, start: date, end: date,
                   route_names: Optional[Dict[str, str]] = None) -> dict:
    dates = [d.isoformat() for d in pd.date_range(start, end).date]
    date_idx = {d: i for i, d in enumerate(dates)}
    routes, rows, trips, trip_idx = [], [], [], {}
    if len(tp):
        h = tp.copy()
        h["direction_id"] = h.direction_id.fillna("").astype(str)
        starts = h.groupby("trip_id").required_leave_secs.min()
        groups = sorted(h.groupby("route_id"), key=lambda kv: str(kv[1].route_short_name.iloc[0]))
        for r_i, (route_id, rg) in enumerate(groups):
            tps = (rg.groupby(["direction_id", "stop_id"], sort=False)
                     .agg(name=("stop_name", "first"), seq=("stop_sequence", "median"))
                     .reset_index().sort_values(["direction_id", "seq"]))
            names = tps.name.tolist()
            labels, tp_idx = [], {}
            for k, t in enumerate(tps.itertuples()):
                labels.append(t.name + (f" (direction {t.direction_id or '?'})" if names.count(t.name) > 1 else ""))
                tp_idx[(t.direction_id, t.stop_id)] = k
            long_name = (route_names or {}).get(route_id, "")
            routes.append({"short": str(rg.route_short_name.iloc[0]).strip() or str(route_id),
                           "name": str(long_name or "").strip(), "timepoints": labels})
            for s in rg.itertuples():
                if s.trip_id not in trip_idx:
                    trip_idx[s.trip_id] = len(trips)
                    trips.append([s.trip_id, int(starts[s.trip_id])])
                dev = None if pd.isna(s.deviation_s) else int(s.deviation_s)
                rows.append([date_idx[s.service_date], r_i, tp_idx[(s.direction_id, s.stop_id)],
                             trip_idx[s.trip_id], int(s.required_leave_secs), dev])
    return {"feed_id": feed_id, "timezone": timezone, "start": start.isoformat(), "end": end.isoformat(),
            "dates": dates, "routes": routes, "trips": trips, "rows": rows}


def build_report(tp: pd.DataFrame, feed_id: str, timezone: str, start: date, end: date, out_path: Path,
                 route_names: Optional[Dict[str, str]] = None) -> Path:
    payload = report_payload(tp, feed_id, timezone, start, end, route_names)
    template = (Path(__file__).parent / "report_template.html").read_text(encoding="utf-8")
    title = f"{feed_id} timepoint leave times {start.isoformat()}" + ("" if start == end else f" to {end.isoformat()}")
    html = template.replace("__DATA__", json.dumps(payload, separators=(",", ":")).replace("</", "<\\/"))
    html = html.replace("__TITLE__", title)
    tmp = out_path.with_name(out_path.name + ".tmp")
    tmp.write_text(html, encoding="utf-8")
    tmp.replace(out_path)
    return out_path
