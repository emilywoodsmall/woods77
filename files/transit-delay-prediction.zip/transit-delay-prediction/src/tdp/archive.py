"""Download historical Vehicle Positions from a public GTFS-RT archive.

Currently supports gtfsrt.io, which publishes one flattened Parquet file per feed per UTC date:

    http://parquet.gtfsrt.io/vehicle_positions/date=YYYY-MM-DD/base64url=<key>/data.parquet

where <key> is the feed's live URL encoded as URL-safe base64 without padding.
See docs/data_sources.md for details and caveats (third-party service, UTC partitioning).
Downloads are cached: a file that already exists locally is never downloaded again.
"""
from __future__ import annotations

import base64
import logging
import os
import urllib.error
import urllib.request
from datetime import date, timedelta
from pathlib import Path
from typing import List, Optional

from .config import Archive

log = logging.getLogger(__name__)


def b64url(url: str) -> str:
    return base64.urlsafe_b64encode(url.encode()).decode().rstrip("=")


def gtfsrt_io_url(archive: Archive, utc_date: date) -> str:
    if not archive.vehicle_positions_url:
        raise ValueError("Config needs archive.vehicle_positions_url to download history")
    return (f"{archive.base_url.rstrip('/')}/vehicle_positions/date={utc_date.isoformat()}"
            f"/base64url={b64url(archive.vehicle_positions_url)}/data.parquet")


def fetch_utc_day(archive: Archive, utc_date: date, cache_dir: Path) -> Optional[Path]:
    """Return a local path to that UTC day's file, downloading it if needed. None if unavailable."""
    if archive.provider != "gtfsrt_io":
        raise ValueError(f"Unsupported archive provider {archive.provider!r}")
    dest = cache_dir / "gtfsrt_io" / "vehicle_positions" / f"date={utc_date.isoformat()}" / "data.parquet"
    if dest.exists():
        return dest
    url = gtfsrt_io_url(archive, utc_date)
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name("data.parquet.part")
    try:
        urllib.request.urlretrieve(url, tmp)
    except (urllib.error.URLError, OSError) as e:
        log.warning("archive_download_failed date=%s url=%s error=%s", utc_date, url, e)
        if tmp.exists():
            tmp.unlink()
        return None
    os.replace(tmp, dest)
    log.info("archive_downloaded date=%s bytes=%d", utc_date, dest.stat().st_size)
    return dest


def files_for_service_date(archive: Archive, service_date: date, cache_dir: Path) -> List[Path]:
    """A service day spans two UTC dates (evening trips run past midnight UTC), so fetch both."""
    out = []
    for d in (service_date, service_date + timedelta(days=1)):
        p = fetch_utc_day(archive, d, cache_dir)
        if p is not None:
            out.append(p)
    return out
