# Transit Schedule Adherence Analyzer

Measures when buses actually left each timepoint, from an agency's GTFS schedule and
GTFS-Realtime vehicle positions, and compares it with the scheduled leave time across many days.

Full instructions, including how to get GTFS and GTFS-Realtime data, and an example:
**https://www.woods77.com/transit**

## Quick start (Python 3.9 or newer)

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e .

python -m tdp.history --start 2026-09-01 --end 2026-09-30 \
    --gtfs path/to/gtfs.zip --rt path/to/realtime/
```

Results are written to `output/<feed>/history_<start>_to_<end>/`:
`report.html`, `leave_times.csv`, `leave_times.parquet` and `leave_times_by_run.csv`.

Agency-specific settings (optional) go in a copy of `config/example.yaml`, passed with `--config`.
