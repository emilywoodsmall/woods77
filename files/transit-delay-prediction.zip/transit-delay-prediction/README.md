# Transit Delay Forecasting Engine

Reconstruct **when buses actually left their timepoints**, stop by stop and day by day, from
public transit data: an agency's **GTFS schedule** plus its **GTFS-Realtime vehicle positions**.
The long-term goal is to forecast leave times; the current release builds the trustworthy
historical record that any forecast must be trained and tested on.

The code is agency-independent. Butler County Regional Transit Authority (BCRTA, Ohio) is the
first test case; agency-specific settings live in a small configuration file.

## Project status

| Part | Status |
|---|---|
| Read any standard GTFS schedule (zip or folder) | **Available** |
| Read realtime vehicle positions: raw `.pb` files, gtfsrt.io archive files, or your own CSV/Parquet | **Available** |
| Estimate actual arrival, departure, and passing times at every stop, with the method and uncertainty recorded | **Available** |
| One day of scheduled vs. actual leave times (`python -m tdp`) | **Available** |
| Many days: one scheduled leave time per run compared with every day's actual leave time (`python -m tdp.history`) | **Available** |
| Use your own realtime files, read one day at a time | **Available** |
| Optional download of past data from the gtfsrt.io archive | **Available** |
| Live collector that saves the agency's feed every 20 seconds | Planned, next |
| Use of Trip Updates (cancellations, skipped stops) | Planned |
| Several schedule versions in one run | Planned |
| Find runs that are consistently late and recommend adjusted scheduled times | Planned |
| Prediction from past days with LightGBM, tested against simple baselines (`python -m tdp.model`) | **Available** (needs 14+ days of history) |
| Live predictions for trips in progress | Planned |

Details, order, and reasoning are in [ROADMAP.md](ROADMAP.md).

## What you get

The main output compares **the same scheduled leave time** (one run of a route at one timepoint,
which repeats every day) **with the actual leave time on each day**. Three files, in
`output/<feed_id>/history_<start>_to_<end>/`:

| File | What it is |
|---|---|
| `leave_times.csv` (and `.parquet`) | One row per run, timepoint, and day. Columns: `service_date, weekday, route, trip_id, stop_sequence, stop_id, stop_name, scheduled_leave, actual_leave, minutes_late` |
| `leave_times_by_run.csv` | One row per run and timepoint, then one column per date holding that day's minutes late. Blank = no measurement (no data, or the run did not operate that day) |
| `report.html` | For each route (use Previous/Next): a chart of every departure's minutes late against its scheduled leave time, and a table of all departures. No analysis |

`scheduled_leave` and `actual_leave` use the same clock (time of the service day, `HH:MM:SS`, which
can pass `24:00:00` after midnight, as in GTFS), so they can be compared directly.
`minutes_late` is negative when the bus left early.

Supporting files for auditing are in `details/` (full-detail table, per-day data coverage).
Examples from BCRTA, 16 September 2026, are in [`docs/examples/`](docs/examples/).
A single day (`python -m tdp`) produces the same `leave_times.csv` and `report.html` in
`output/<feed_id>/<date>/`, plus stop-level detail.

**For analysis or machine learning, use `leave_times.parquet`**: it keeps column types (dates,
numbers, text IDs), is small, and loads directly in Python (pandas, Polars), R, DuckDB, or Spark.
Use the CSV files for spreadsheets.

## Quick start

Requires Python 3.9 or newer.

```bash
git clone <this repository>
cd transit-delay-prediction
python3 -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
python -m pip install --upgrade pip  # older pip versions cannot install this project
pip install -e ".[test,model]"
```

**You need two inputs:**

1. The agency's **GTFS schedule**: the `.zip` file, or a folder of its `.txt` files.
2. **GTFS-Realtime Vehicle Positions** for the days you want, in any of these forms:
   * a folder of raw `.pb` snapshots, as saved from the agency's feed (subfolders are fine; file
     names containing the fetch time, like `2026-09-16T08-00-20Z.pb`, make reading faster);
   * flattened Parquet files, such as those from the gtfsrt.io archive;
   * your own CSV or Parquet export with any column names, mapped in the config file
     (`rt_format: table` and `rt_columns`, see `config/feeds/example.yaml`).

**Many days from your own files:**

```bash
python -m tdp.history --start 2026-09-01 --end 2026-09-30 \
    --gtfs path/to/gtfs.zip --rt path/to/realtime_folder/ --config config/feeds/my_agency.yaml
```

Point `--rt` at one folder holding the whole period; each record is assigned to its correct
service day, however the files are split. Files are read one day at a time, so months of data do
not need to fit in memory. Days already processed are reused when you rerun with a longer range.

**One day:**

```bash
python -m tdp --gtfs path/to/gtfs.zip --rt path/to/realtime_folder/ --date 2026-09-16
```

**Optional: no files of your own?** If `--rt` is left out, `tdp.history` downloads past data
from the gtfsrt.io archive for the feed URL set under `archive:` in the config. Downloads are
cached in `data/archive/`. See [docs/data_sources.md](docs/data_sources.md).

Each service day needs realtime data covering its full span, which in the Americas crosses
midnight UTC. `details/daily_summary.csv` flags days where only part of the day was covered.

**Predict leave times from the history (needs at least 14 days):**

```bash
python -m tdp.model --history output/bcrta/history_2026-08-23_to_2026-09-22/leave_times.parquet
```

This trains a LightGBM model on all but the most recent 7 days, measures its accuracy on those
7 days against two simple alternatives ("leaves on schedule" and "this run's typical lateness so
far"), then writes `model/predictions.csv`: for every run, timepoint, and weekday, the predicted
typical minutes late, a "late day" value that 80% of days stay at or below, and the matching
predicted leave times. It uses only information known in advance (route, run, timepoint, scheduled
time, weekday). If the model does not beat "typical lateness so far" in `model/evaluation.csv`,
use that simpler figure instead. On macOS, LightGBM needs `brew install libomp`; without it the
program automatically uses scikit-learn's equivalent model.

**A new agency:** copy `config/feeds/example.yaml` and set `feed_id` (plus `rt_columns` if you
use your own CSV). The GTFS schedule must be the version in effect on the dates you process.

## How it works (short version)

1. Each GPS position is placed at a distance along the trip's route, using `shapes.txt` from the
   schedule. Placement only moves forward, so loop routes work.
2. For each stop, the best available evidence is used, in this fixed order:
   1. the feed reports the bus is stopped at the stop (only some agencies provide this);
   2. GPS shows the bus standing at the stop, so arrival and departure are measured separately;
   3. the moment the bus passed the stop, interpolated between two GPS positions no more than
      2 minutes apart;
   4. otherwise nothing: the stop is recorded as not measured. **No time is ever guessed, and
      predicted times from the feed are never treated as actual times.**
3. Every time records its method, an uncertainty in seconds, and the moment it became knowable
   (used later to prevent forecasting models from "seeing the future").

Full detail: [docs/methodology.md](docs/methodology.md). Design rationale:
[docs/architecture.md](docs/architecture.md).

## Limitations

Please read [docs/limitations.md](docs/limitations.md) before using results in research. In short:
times are GPS-based estimates (typically within 10 to 30 seconds); missing data is not random;
cancellations and skipped stops are not yet distinguished from missing data; historical realtime
data comes from a third-party archive whose completeness is unverified; and one schedule version
is used per run.

## Data sources

* **GTFS schedules** are published by each agency, usually on its website or via
  [Mobility Database](https://mobilitydatabase.org) and [Transitland](https://www.transit.land).
* **Realtime data**: your own saved snapshots or exports; or, optionally, the gtfsrt.io archive,
  which publishes daily files of many agencies' GTFS-Realtime feeds with no login. See [docs/data_sources.md](docs/data_sources.md) for how its
  files are organized, a worked example, and caveats. This project is not affiliated with gtfsrt.io.

## Project layout

```
config/feeds/        agency settings (bcrta.yaml, example.yaml)
docs/                methodology, limitations, data sources, design document, example reports
src/tdp/
  static_gtfs.py     read and check the schedule; service calendars; route paths
  realtime.py        read vehicle positions (.pb, archive Parquet, CSV) into one format
  geo.py             place GPS points and stops along route paths
  reconstruct.py     estimate stop times using the evidence order above
  outputs.py         write CSV/Parquet outputs
  report.py          HTML report             (report_template.html)
  archive.py         download from gtfsrt.io
  history.py         multi-day history and the simple comparison tables
  model.py           LightGBM prediction and evaluation
  cli.py             `python -m tdp`
tests/               automated tests with synthetic data whose answers are known
```

## Tests

```bash
pytest
```

The tests cover after-midnight trips, both 2026 daylight-saving changes, loop routes, duplicate and
out-of-order data, stale data, service-date inference, feed-reported stop status, vendor
quirks, `.pb` decoding, the gtfsrt.io address format, multi-day history, and identical output
when rerun. They run automatically on GitHub for Python 3.9 and 3.12.

## License and citation

No license has been chosen yet. Until one is added, others may read the code but not legally
reuse it. For an open research tool, MIT or Apache-2.0 are common choices.
