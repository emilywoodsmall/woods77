"""Using your own realtime files: every format is read one day at a time."""
from datetime import date, datetime, timezone

import pandas as pd
import pytest

from synthetic import fix_rows, make_gtfs, write_fixes
from tdp.config import FeedConfig
from tdp.history import build_history
from tdp.realtime import RealtimeSource
from tdp.reconstruct import service_window
from tdp.static_gtfs import StaticFeed


def write_pb_folder(folder, rows, timestamp_names=True):
    from google.transit import gtfs_realtime_pb2
    folder.mkdir(parents=True, exist_ok=True)
    for i, row in enumerate(rows):
        msg = gtfs_realtime_pb2.FeedMessage()
        msg.header.gtfs_realtime_version = "2.0"
        msg.header.timestamp = row["available_at"]
        e = msg.entity.add(); e.id = "v1"
        v = e.vehicle
        v.trip.trip_id = row["trip_id"]; v.trip.start_date = row["start_date"]
        v.vehicle.id = row["vehicle_id"]
        v.position.latitude = float(row["latitude"]); v.position.longitude = float(row["longitude"])
        v.position.speed = float(row["speed"]); v.timestamp = row["timestamp"]
        stamp = datetime.fromtimestamp(row["available_at"], tz=timezone.utc).strftime("%Y-%m-%dT%H-%M-%SZ")
        name = f"vp_{stamp}.pb" if timestamp_names else f"snapshot_{i:05d}.pb"
        (folder / name).write_bytes(msg.SerializeToString())
    return folder


def two_days():
    return fix_rows(day="2026-09-16", start_date="20260916") + fix_rows(day="2026-09-17", start_date="20260917")


@pytest.mark.parametrize("timestamp_names", [True, False])
def test_pb_folder_is_read_one_day_at_a_time(tmp_path, timestamp_names):
    folder = write_pb_folder(tmp_path / "pb", two_days(), timestamp_names)
    feed = StaticFeed.load(str(make_gtfs(tmp_path / "gtfs")))
    cfg = FeedConfig(feed_id="t")
    src = RealtimeSource([str(folder)], cfg)
    assert src.format == "pb"
    df, stats = src.load(service_window(feed, date(2026, 9, 16), cfg.thresholds))
    assert len(df) == 13 and set(df.start_date) == {"20260916"}
    assert stats["files_read"] == 13  # the other day's 13 files were never decoded


def test_csv_is_filtered_to_the_day(tmp_path):
    csv = write_fixes(tmp_path / "fx.csv", two_days())
    feed = StaticFeed.load(str(make_gtfs(tmp_path / "gtfs")))
    cfg = FeedConfig(feed_id="t", rt_format="table")
    cfg.rt_columns.available_at = "available_at"
    df, _ = RealtimeSource([str(csv)], cfg).load(service_window(feed, date(2026, 9, 17), cfg.thresholds))
    assert len(df) == 13 and set(df.start_date) == {"20260917"}


def test_history_from_own_pb_folder(tmp_path):
    folder = write_pb_folder(tmp_path / "pb", two_days())
    gtfs = make_gtfs(tmp_path / "gtfs")
    hist = build_history(date(2026, 9, 16), date(2026, 9, 17), str(gtfs), FeedConfig(feed_id="t"),
                         tmp_path / "out", [str(folder)])
    lt = pd.read_csv(hist / "leave_times.csv")
    assert list(lt.service_date) == ["2026-09-16", "2026-09-17"]
    assert lt.actual_leave.tolist() == ["08:00:24", "08:00:24"]
