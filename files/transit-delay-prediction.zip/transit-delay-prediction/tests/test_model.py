from datetime import date, timedelta

import numpy as np
import pandas as pd
import pytest

from tdp.model import run
from tdp.timeutil import format_gtfs_time


def synthetic_history(path, days=35, seed=1):
    """Weekday runs with a known pattern: run T8 is ~6 min late at its 2nd timepoint every day,
    run T16 is ~8 min late on Fridays only, everything else ~1 min late."""
    rng = np.random.default_rng(seed)
    rows = []
    for k in range(days):
        d = date(2026, 8, 24) + timedelta(days=k)
        if d.weekday() >= 5:
            continue
        for h in range(6, 20):
            for seq, off in ((0, 0), (5, 10), (9, 20)):
                sched = h * 3600 + off * 60
                late = 1.0
                if h == 8 and seq == 5:
                    late = 6.0
                if h == 16 and d.weekday() == 4:
                    late = 8.0
                m = None if rng.random() < 0.1 else round(late + rng.normal(0, 1.2), 1)
                rows.append({"service_date": d.isoformat(), "weekday": d.strftime("%A"), "route": "1",
                             "trip_id": f"T{h}", "stop_sequence": seq, "stop_id": f"S{seq}", "stop_name": f"Stop {seq}",
                             "scheduled_leave": format_gtfs_time(sched),
                             "actual_leave": "" if m is None else format_gtfs_time(int(sched + 60 * m)),
                             "minutes_late": m})
    pd.DataFrame(rows).to_csv(path, index=False)
    return path


@pytest.mark.parametrize("engine", ["lightgbm", "sklearn"])
def test_model_learns_known_pattern_and_beats_schedule(tmp_path, engine):
    hist = synthetic_history(tmp_path / "leave_times.csv")
    out = run(str(hist), tmp_path / "model", test_days=5, engine=engine)
    ev = pd.read_csv(out / "evaluation.csv")
    schedule_err, model_err = ev.mean_error_min.iloc[0], ev.mean_error_min.iloc[2]
    assert model_err < schedule_err
    p = pd.read_csv(out / "predictions.csv")
    t8 = p[(p.trip_id == "T8") & (p.stop_sequence == 5)].predicted_minutes_late
    assert t8.between(4.5, 7.5).all()
    fri = p[(p.trip_id == "T16") & (p.weekday == "Friday")].predicted_minutes_late
    mon = p[(p.trip_id == "T16") & (p.weekday == "Monday")].predicted_minutes_late
    assert fri.mean() > mon.mean() + 4
    assert (p.late_day_minutes_late >= p.predicted_minutes_late).all()
    assert list(p.columns) == ["route", "trip_id", "stop_sequence", "stop_id", "stop_name", "weekday",
                               "scheduled_leave", "predicted_minutes_late", "late_day_minutes_late",
                               "predicted_leave", "late_day_leave", "days_measured"]


def test_model_refuses_with_too_few_days(tmp_path):
    hist = synthetic_history(tmp_path / "leave_times.csv", days=5)
    with pytest.raises(ValueError, match="at least 14"):
        run(str(hist), tmp_path / "model")


def test_model_is_deterministic(tmp_path):
    hist = synthetic_history(tmp_path / "leave_times.csv")
    a = run(str(hist), tmp_path / "a", test_days=5)
    b = run(str(hist), tmp_path / "b", test_days=5)
    assert (a / "predictions.csv").read_bytes() == (b / "predictions.csv").read_bytes()
