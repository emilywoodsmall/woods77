import numpy as np

from tdp.geo import Projector, build_path, place_monotone


def test_loop_stop_visited_twice_gets_two_positions():
    proj = Projector(39.4)
    # Square loop ~1 km per side returning to the start.
    x = np.array([0, 1000, 1000, 0, 0.0]); y = np.array([0, 0, 1000, 1000, 0.0])
    lat, lon = proj.latlon(x, y)
    path = build_path(proj, lat, lon)
    sx, sy = proj.xy(*proj.latlon(np.array([0.0, 1000, 0.0]), np.array([0.0, 500, 0.0])))
    d = place_monotone(path, sx, sy, 50)
    assert abs(d[0] - 0) < 1 and abs(d[1] - 1500) < 1 and abs(d[2] - 4000) < 1


def test_candidates_returns_all_nearby_segments():
    proj = Projector(39.4)
    x = np.array([0, 1000, 1000, 0.0]); y = np.array([0, 0, 20, 20.0])  # out and back 20 m apart
    path = build_path(proj, *proj.latlon(x, y))
    c = path.candidates(500.0, 10.0, 50)
    assert len(c) == 2 and abs(c[0] - 500) < 1 and abs(c[1] - 1520) < 1
