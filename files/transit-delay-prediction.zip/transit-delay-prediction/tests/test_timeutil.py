from datetime import date, datetime
from zoneinfo import ZoneInfo

import pytest

from tdp.timeutil import format_gtfs_time, gtfs_to_unix, parse_gtfs_time, service_day_anchor

NY = ZoneInfo("America/New_York")


def local(ts):
    return datetime.fromtimestamp(ts, tz=NY)


def test_parse_beyond_midnight():
    assert parse_gtfs_time("25:30:00") == 91800
    assert parse_gtfs_time(" 08:03:00 ") == 8 * 3600 + 180
    assert parse_gtfs_time("") is None
    assert format_gtfs_time(91800) == "25:30:00"
    with pytest.raises(ValueError):
        parse_gtfs_time("8:61:00")


def test_after_midnight_stays_on_service_date():
    t = local(gtfs_to_unix(date(2026, 9, 16), 91800, NY))
    assert (t.year, t.month, t.day, t.hour, t.minute) == (2026, 9, 17, 1, 30)


def test_spring_forward_uses_noon_minus_12h():
    # 2026-03-08: clocks jump 02:00 EST -> 03:00 EDT. Anchor is 23:00 EST the night before.
    anchor = local(service_day_anchor(date(2026, 3, 8), NY))
    assert (anchor.day, anchor.hour) == (7, 23)
    t = local(gtfs_to_unix(date(2026, 3, 8), 3 * 3600 + 1800, NY))
    assert (t.hour, t.minute, t.utcoffset().total_seconds()) == (3, 30, -4 * 3600)


def test_fall_back_uses_noon_minus_12h():
    # 2026-11-01: clocks fall back 02:00 EDT -> 01:00 EST. Anchor is 01:00 EDT.
    anchor = local(service_day_anchor(date(2026, 11, 1), NY))
    assert (anchor.hour, anchor.utcoffset().total_seconds()) == (1, -4 * 3600)
    t = local(gtfs_to_unix(date(2026, 11, 1), 3600 + 1800, NY))
    assert (t.hour, t.minute, t.utcoffset().total_seconds()) == (1, 30, -5 * 3600)  # the second 01:30


def test_ordinary_day_anchor_is_midnight():
    a = local(service_day_anchor(date(2026, 9, 16), NY))
    assert (a.hour, a.minute) == (0, 0)
