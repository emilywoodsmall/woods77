import hashlib

from synthetic import fix_rows, make_gtfs, write_fixes
from tdp.cli import main


def _hashes(folder):
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(folder.iterdir())}


def test_cli_runs_and_is_deterministic(tmp_path):
    gtfs = make_gtfs(tmp_path / "gtfs")
    fixes = write_fixes(tmp_path / "fixes.csv", fix_rows())
    cfgp = tmp_path / "c.yaml"
    cfgp.write_text("feed_id: synth\nrt_format: table\nrt_columns:\n  available_at: available_at\n")
    args = ["--gtfs", str(gtfs), "--rt", str(fixes), "--date", "2026-09-16", "--config", str(cfgp)]
    assert main(args + ["--out", str(tmp_path / "o1")]) == 0
    assert main(args + ["--out", str(tmp_path / "o2")]) == 0
    h1, h2 = _hashes(tmp_path / "o1/synth/2026-09-16"), _hashes(tmp_path / "o2/synth/2026-09-16")
    assert set(h1) == {"stop_events.csv", "stop_events.parquet", "trips.csv", "timepoint_departures.csv",
                       "qc_summary.json", "report.html", "timepoint_departures.parquet", "leave_times.csv"}
    assert h1 == h2
    import pandas as pd
    tp = pd.read_csv(tmp_path / "o1/synth/2026-09-16/timepoint_departures.csv")
    # Only stop A is a timepoint with a departure (D is the last stop): required 08:00, left 08:00:24.
    assert list(tp.stop_name) == ["Stop A"]
    assert tp.deviation_s.iloc[0] == 24 and tp.status.iloc[0] == "on_time"
