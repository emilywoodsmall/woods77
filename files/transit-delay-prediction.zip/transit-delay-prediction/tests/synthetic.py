"""Tiny synthetic GTFS + GTFS-RT fixtures with known ground truth (architecture doc, section 16)."""
from __future__ import annotations

import csv
import math
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
from zoneinfo import ZoneInfo

TZ = ZoneInfo("America/New_York")
LAT0, LON0 = 39.4, -84.56
R = 6371000.0


def lon_at(d_m: float) -> float:
    """Longitude of a point d_m metres east of the origin (same projection the pipeline uses)."""
    return LON0 + math.degrees(d_m / (R * math.cos(math.radians(LAT0))))


def unix(service_day: str, hms: str) -> float:
    y, m, d = (int(x) for x in service_day.split("-"))
    h, mi, s = (int(x) for x in hms.split(":"))
    return datetime(y, m, d, h, mi, s, tzinfo=TZ).timestamp()


def _write(path: Path, rows: List[Dict[str, object]]) -> None:
    with path.open("w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


STOPS = [("A", 0), ("B", 800), ("C", 1600), ("D", 2400)]


def make_gtfs(folder: Path, trips: Optional[List[Dict[str, object]]] = None) -> Path:
    """One route, one straight 2.4 km shape, four stops. Default trip T100 = doc example."""
    folder.mkdir(parents=True, exist_ok=True)
    trips = trips or [{"trip_id": "T100", "times": ["08:00:00", "08:03:00", "08:06:00", "08:09:00"],
                       "timepoints": [1, 0, 0, 1]}]
    _write(folder / "agency.txt", [{"agency_id": "X", "agency_name": "Synthetic", "agency_url": "https://example.com",
                                    "agency_timezone": "America/New_York"}])
    _write(folder / "routes.txt", [{"route_id": "R1", "agency_id": "X", "route_short_name": "1",
                                    "route_long_name": "Test Line", "route_type": 3, "route_color": "2E7D32"}])
    _write(folder / "calendar.txt", [{"service_id": "ALL", "monday": 1, "tuesday": 1, "wednesday": 1, "thursday": 1,
                                      "friday": 1, "saturday": 1, "sunday": 1, "start_date": "20260101",
                                      "end_date": "20261231"}])
    _write(folder / "stops.txt", [{"stop_id": s, "stop_name": f"Stop {s}", "stop_lat": LAT0, "stop_lon": f"{lon_at(d):.8f}"}
                                  for s, d in STOPS])
    _write(folder / "shapes.txt", [{"shape_id": "S1", "shape_pt_lat": LAT0, "shape_pt_lon": f"{lon_at(d):.8f}",
                                    "shape_pt_sequence": i} for i, d in enumerate(range(0, 2401, 200))])
    _write(folder / "trips.txt", [{"route_id": "R1", "service_id": "ALL", "trip_id": t["trip_id"], "direction_id": 0,
                                   "block_id": "B1", "shape_id": "S1"} for t in trips])
    st = []
    for t in trips:
        for i, ((sid, _), tm, tp) in enumerate(zip(STOPS, t["times"], t["timepoints"])):
            st.append({"trip_id": t["trip_id"], "arrival_time": tm, "departure_time": tm, "stop_id": sid,
                       "stop_sequence": i, "timepoint": tp})
    _write(folder / "stop_times.txt", st)
    return folder


# (local time, distance m, speed m/s) for trip T100 on 2026-09-16, exactly as in the doc.
DOC_FIXES = [
    ("08:00:00", 0, 0), ("08:00:20", 5, 0), ("08:00:40", 120, 8), ("08:01:00", 300, 9), ("08:01:20", 480, 9),
    ("08:01:40", 660, 6), ("08:02:00", 790, 0), ("08:02:20", 800, 0), ("08:02:40", 810, 0), ("08:03:00", 900, 5),
    ("08:08:00", 2300, 4), ("08:08:20", 2390, 0), ("08:08:40", 2400, 0),
]


def fix_rows(fixes=DOC_FIXES, day: str = "2026-09-16", trip_id: str = "T100", vehicle: str = "7405",
             start_date: Optional[str] = "20260916", extra: Optional[Dict[str, object]] = None) -> List[Dict[str, object]]:
    rows = []
    for hms, d, v in fixes:
        ts = unix(day, hms)
        row = {"vehicle_id": vehicle, "trip_id": trip_id, "latitude": LAT0, "longitude": f"{lon_at(d):.8f}",
               "timestamp": int(ts), "start_date": start_date or "", "speed": v, "available_at": int(ts) + 3,
               "entity_id": f"veh_{vehicle}"}
        row.update(extra or {})
        rows.append(row)
    return rows


def write_fixes(path: Path, rows: List[Dict[str, object]]) -> Path:
    _write(path, rows)
    return path
