import hashlib
from datetime import date

import pandas as pd

from synthetic import fix_rows, make_gtfs, write_fixes
from tdp.archive import b64url, gtfsrt_io_url
from tdp.config import Archive, FeedConfig
from tdp.history import build_history


def cfg():
    c = FeedConfig(feed_id="synth", rt_format="table")
    c.rt_columns.available_at = "available_at"
    return c


def test_archive_url_matches_gtfsrt_io_example():
    url = "https://www.buztrakr.com/gtfs-rt/vehiclepositions"
    assert b64url(url) == "aHR0cHM6Ly93d3cuYnV6dHJha3IuY29tL2d0ZnMtcnQvdmVoaWNsZXBvc2l0aW9ucw"
    assert gtfsrt_io_url(Archive(vehicle_positions_url=url), date(2026, 9, 22)) == (
        "http://parquet.gtfsrt.io/vehicle_positions/date=2026-09-22/"
        "base64url=aHR0cHM6Ly93d3cuYnV6dHJha3IuY29tL2d0ZnMtcnQvdmVoaWNsZXBvc2l0aW9ucw/data.parquet")


def test_history_over_several_days(tmp_path):
    gtfs = make_gtfs(tmp_path / "gtfs")
    rows = fix_rows(day="2026-09-16", start_date="20260916") + fix_rows(day="2026-09-17", start_date="20260917")
    fixes = write_fixes(tmp_path / "fixes.csv", rows)
    out = tmp_path / "out"
    hist = build_history(date(2026, 9, 16), date(2026, 9, 18), str(gtfs), cfg(), out, [str(fixes)])
    tp = pd.read_csv(hist / "details/timepoint_departures.csv")
    daily = pd.read_csv(hist / "details/daily_summary.csv")
    simple = pd.read_csv(hist / "leave_times.csv")
    wide = pd.read_csv(hist / "leave_times_by_run.csv")
    assert list(simple.columns) == ["service_date", "weekday", "route", "trip_id", "stop_sequence", "stop_id",
                                    "stop_name", "scheduled_leave", "actual_leave", "minutes_late"]
    assert simple.scheduled_leave.iloc[0] == "08:00:00" and simple.actual_leave.iloc[0] == "08:00:24"
    # one row per run+timepoint, one column per day
    assert len(wide) == 1 and list(wide.columns[-3:]) == ["2026-09-16", "2026-09-17", "2026-09-18"]
    assert wide["2026-09-16"].iloc[0] == 0.4 and pd.isna(wide["2026-09-18"].iloc[0])
    # Stop A is the only timepoint with a departure; one per day for the 3 scheduled days.
    assert len(tp) == 3 and tp.deviation_s.notna().sum() == 2
    assert list(daily.status) == ["ok", "ok", "no_realtime_data"]
    assert (hist / "report.html").exists()

    first = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in hist.iterdir() if p.is_file()}
    hist2 = build_history(date(2026, 9, 16), date(2026, 9, 18), str(gtfs), cfg(), out, [str(fixes)])
    second = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in hist2.iterdir() if p.is_file()}
    assert first == second
    assert "ok (reused)" in pd.read_csv(hist2 / "details/daily_summary.csv").status.tolist()


def test_days_outside_the_schedule_are_skipped(tmp_path):
    gtfs = make_gtfs(tmp_path / "gtfs")
    fixes = write_fixes(tmp_path / "fixes.csv", fix_rows())
    hist = build_history(date(2025, 12, 31), date(2025, 12, 31), str(gtfs), cfg(), tmp_path / "o", [str(fixes)])
    daily = pd.read_csv(hist / "details/daily_summary.csv")
    assert list(daily.status) == ["no_schedule"]
