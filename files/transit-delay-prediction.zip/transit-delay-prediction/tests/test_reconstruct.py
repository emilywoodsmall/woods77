"""End-to-end tests on synthetic data with known answers (architecture doc, section 16)."""
from datetime import date

import pytest

from synthetic import fix_rows, make_gtfs, unix, write_fixes
from tdp.config import FeedConfig, TripRule
from tdp.realtime import load_vehicle_fixes
from tdp.reconstruct import reconstruct_day
from tdp.static_gtfs import StaticFeed

DAY = date(2026, 9, 16)


def cfg():
    c = FeedConfig(feed_id="synthetic", rt_format="table")
    c.rt_columns.available_at = "available_at"
    return c


def run(tmp_path, rows, c=None, gtfs_trips=None, day=DAY):
    c = c or cfg()
    feed = StaticFeed.load(str(make_gtfs(tmp_path / "gtfs", gtfs_trips)))
    fixes, _, _ = load_vehicle_fixes([str(write_fixes(tmp_path / "fixes.csv", rows))], c)
    return reconstruct_day(feed, fixes, day, c)


def ev(result, seq):
    return result.events[result.events.stop_sequence == seq].iloc[0]


def test_doc_example(tmp_path):
    r = run(tmp_path, fix_rows())
    a, b, c, d = (ev(r, i) for i in range(4))
    # A: first stop, departure only (bus waited, then left the 30 m radius)
    assert a.arrival_unix is None or a.arrival_unix != a.arrival_unix
    assert a.departure_unix == pytest.approx(unix("2026-09-16", "08:00:24"), abs=1)
    assert a.departure_method == "gps_dwell" and a.departure_delay_s == 24
    # B: dwell -> separate arrival and departure
    assert b.arrival_unix == pytest.approx(unix("2026-09-16", "08:01:57"), abs=1)
    assert b.departure_unix == pytest.approx(unix("2026-09-16", "08:02:44"), abs=1)
    assert (b.arrival_delay_s, b.departure_delay_s) == (-63, -16)
    assert b.arrival_method == b.departure_method == "gps_dwell"
    # C: GPS gap of 300 s > 120 s limit -> no time is invented
    assert c.event_status == "no_evidence" and c.passage_unix != c.passage_unix
    # D: last stop, arrival only
    assert d.arrival_unix == pytest.approx(unix("2026-09-16", "08:08:16"), abs=1)
    assert d.arrival_delay_s == -44 and (d.departure_unix != d.departure_unix)
    # knowable_at is when the later bracketing fix became available, never earlier than the event
    assert b.knowable_at_unix >= b.departure_unix


def test_every_scheduled_visit_is_present_even_without_data(tmp_path):
    r = run(tmp_path, fix_rows(trip_id="T100", start_date="20260917"))  # data is for another day
    assert len(r.events) == 4 and set(r.events.event_status) == {"no_data"}


def test_duplicate_and_out_of_order_fixes(tmp_path):
    rows = fix_rows()
    shuffled = rows[::-1] + rows[:5]  # reversed order plus duplicates
    r1 = run(tmp_path, rows)
    r2 = run(tmp_path / "b", shuffled)
    cols = ["stop_sequence", "arrival_unix", "departure_unix", "passage_unix"]
    assert r1.events[cols].fillna(-1).equals(r2.events[cols].fillna(-1))


def test_stale_fixes_are_dropped(tmp_path):
    rows = fix_rows()
    for row in rows:
        row["available_at"] = row["timestamp"] + 3600  # an hour old when fetched
    c = cfg()
    r = run(tmp_path, rows, c)
    assert set(r.events.event_status) == {"no_data"}


def test_service_date_inferred_after_midnight(tmp_path):
    trips = [{"trip_id": "LATE", "times": ["24:10:00", "24:13:00", "24:16:00", "24:19:00"], "timepoints": [1, 1, 1, 1]}]
    fixes = [(h, dd, v) for (h, dd, v) in [("00:09:40", 0, 0), ("00:10:00", 5, 0), ("00:10:20", 150, 8),
                                          ("00:10:40", 400, 9), ("00:11:00", 700, 9), ("00:11:20", 900, 9)]]
    rows = fix_rows(fixes, day="2026-09-17", trip_id="LATE", start_date=None)
    r = run(tmp_path, rows, gtfs_trips=trips, day=DAY)
    b = ev(r, 1)
    assert b.event_status == "served" and b.service_date == "2026-09-16"
    assert abs(b.passage_delay_s) < 120
    r_next = run(tmp_path / "n", rows, gtfs_trips=trips, day=date(2026, 9, 17))
    assert set(r_next.events.event_status) == {"no_data"}  # not double-counted on the next date


def test_feed_reported_stop_status_outranks_gps(tmp_path):
    rows = fix_rows()
    for row in rows:
        row["current_status"] = ""
        row["current_stop_sequence"] = ""
    for row in rows[6:9]:  # the three fixes at stop B
        row["current_status"] = 1
        row["current_stop_sequence"] = 1
    c = cfg()
    c.rt_columns.current_status = "current_status"
    c.rt_columns.current_stop_sequence = "current_stop_sequence"
    r = run(tmp_path, rows, c)
    b = ev(r, 1)
    assert b.arrival_method == "observed_stop_status" and b.departure_method == "observed_stop_status"
    assert b.arrival_unix == pytest.approx(unix("2026-09-16", "08:01:50"), abs=1)   # midpoint 08:01:40-08:02:00
    assert b.departure_unix == pytest.approx(unix("2026-09-16", "08:02:50"), abs=1)  # midpoint 08:02:40-08:03:00


def test_trip_rule_recovers_blank_trip_id(tmp_path):
    rows = fix_rows(trip_id="", extra={"entity_id": "detour_9_trip_T100"})
    c = cfg()
    c.trip_rules = [TripRule(name="detour", entity_id_regex=r"^detour_\d+_trip_(?P<trip_id>.+)$", stream="detour")]
    r = run(tmp_path, rows, c)
    assert ev(r, 1).event_status == "served"


def test_pb_input_matches_table_input(tmp_path):
    from google.transit import gtfs_realtime_pb2

    rows = fix_rows()
    folder = tmp_path / "pb"
    folder.mkdir()
    for i, row in enumerate(rows):  # one snapshot per fix
        msg = gtfs_realtime_pb2.FeedMessage()
        msg.header.gtfs_realtime_version = "2.0"
        msg.header.timestamp = row["available_at"]
        e = msg.entity.add(); e.id = "v1"
        v = e.vehicle
        v.trip.trip_id = row["trip_id"]; v.trip.start_date = row["start_date"]
        v.vehicle.id = row["vehicle_id"]
        v.position.latitude = float(row["latitude"]); v.position.longitude = float(row["longitude"])
        v.position.speed = float(row["speed"]); v.timestamp = row["timestamp"]
        (folder / f"snap_{i:03d}.pb").write_bytes(msg.SerializeToString())
    c = cfg(); c.rt_format = "auto"
    feed = StaticFeed.load(str(make_gtfs(tmp_path / "gtfs")))
    fixes, _, fmt = load_vehicle_fixes([str(folder)], c)
    assert fmt == "pb"
    r_pb = reconstruct_day(feed, fixes, DAY, c)
    r_tab = run(tmp_path / "t", rows)
    # float32 coordinates in protobuf -> allow ~1 s
    for seq in range(4):
        a, b = ev(r_pb, seq), ev(r_tab, seq)
        assert a.event_status == b.event_status
        if a.passage_unix == a.passage_unix:
            assert a.passage_unix == pytest.approx(b.passage_unix, abs=1.5)
