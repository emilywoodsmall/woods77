# Roadmap

The project is built in stages. Each stage must produce trustworthy, checkable output before the
next one starts, because a forecasting model trained on wrong labels simply learns the errors.
The full design is in [docs/architecture.md](docs/architecture.md).

## Stage 1: Reconstruct what happened (current)

| Item | Status | Notes |
|---|---|---|
| Static GTFS loading and checks (zip or folder, calendars, exceptions, shapes, timepoints) | Done | Times past 24:00 and daylight-saving days handled per the GTFS spec |
| Realtime vehicle positions from `.pb`, archive Parquet, or CSV/Parquet with column mapping | Done | |
| Stop-time estimation with evidence order, uncertainty, and `knowable_at` | Done | GPS dwell, GPS passage, feed-reported stop status |
| One-day report and CSV/Parquet outputs | Done | `python -m tdp` |
| Your own realtime files (`.pb`, Parquet, CSV) read one day at a time | Done | Months of data without running out of memory |
| Multi-day history with optional gtfsrt.io download and caching | Done | `python -m tdp.history`; simple long and wide comparison tables plus a plain report |
| Identical output on rerun; automated tests | Done | GitHub Actions on Python 3.9 and 3.12 |
| **Live collector** | Next | Poll the agency's feed every 20 s; store every raw snapshot, including empty and failed fetches, so outages can be told apart from "no buses". Removes dependence on third-party archives |
| **Trip Updates evidence** | Planned | Detect canceled trips and skipped stops (now counted as "not measured"); add the "stop dropped from predictions" timing as a weaker, labeled fallback; keep a history of predictions for later accuracy studies |
| **Several schedule versions** | Planned | Choose automatically which GTFS version governs each date, so a date range can cross a schedule change |
| Frequency-based trips (`frequencies.txt`) | Planned | Currently warned about and treated as single runs |
| Detour detection | Planned | Flag stretches where GPS leaves the mapped route |

## Stage 2: Describe and predict from history

| Item | Status | Notes |
|---|---|---|
| Consistently late runs and recommended schedule | Planned | For each run and timepoint, summarise minutes late across days (e.g. median, 80th percentile), flag runs that are late on most days, and propose adjusted scheduled leave times. Reads `leave_times.parquet` |
| Historical baseline | Done | Part of `tdp.model` evaluation: each run's median lateness at each timepoint so far |
| Honest evaluation | Done | Train on earlier days, test on the latest 7; report error in minutes against two baselines |
| Machine-learning model (LightGBM) | Done (first version) | `python -m tdp.model`. Uses route, run, timepoint, scheduled time, weekday. Typical (median) and late-day (80th percentile) predictions |
| More model inputs | Planned | Weather, school calendar, the same bus's lateness on its previous trip (needs `knowable_at` to stay leakage-free) |

## Stage 3: Live prediction

| Item | Status | Notes |
|---|---|---|
| Predict the next timepoints of trips in progress | Planned | Uses the bus's current lateness plus history; relies on `knowable_at` so training never uses information that would not have been available yet |
| Compare with the agency's own predictions | Planned | Uses the stored prediction history |

## Not planned

* Door-open/close or passenger counts: not available in public GTFS-Realtime feeds.
* A hosted service or database server: files plus DuckDB are enough at this scale.
